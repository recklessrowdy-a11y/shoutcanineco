"use client";

import { FormEvent, useState } from "react";
import { buildEnrichmentPlan, EnrichmentInput } from "@/lib/enrichment";
import styles from "./EnrichmentGenerator.module.css";

const initial: EnrichmentInput = {
  age: "adult",
  energy: "medium",
  foodMotivation: "medium",
  toyMotivation: "medium",
  mobility: "none",
  environment: "either",
  minutes: "20"
};

export function EnrichmentGenerator() {
  const [form, setForm] = useState<EnrichmentInput>(initial);
  const [plan, setPlan] = useState<ReturnType<typeof buildEnrichmentPlan> | null>(null);

  function update<K extends keyof EnrichmentInput>(key: K, value: EnrichmentInput[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    setPlan(buildEnrichmentPlan(form));
  }

  function printPlan() {
    window.print();
  }

  return (
    <div className={styles.layout}>
      <form className={styles.form} onSubmit={submit}>
        <Field label="Age">
          <select value={form.age} onChange={(e) => update("age", e.target.value as EnrichmentInput["age"])}>
            <option value="puppy">Puppy</option>
            <option value="adult">Adult</option>
            <option value="senior">Senior</option>
          </select>
        </Field>

        <Field label="Energy level">
          <select value={form.energy} onChange={(e) => update("energy", e.target.value as EnrichmentInput["energy"])}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </Field>

        <Field label="Food motivation">
          <select value={form.foodMotivation} onChange={(e) => update("foodMotivation", e.target.value as EnrichmentInput["foodMotivation"])}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </Field>

        <Field label="Toy motivation">
          <select value={form.toyMotivation} onChange={(e) => update("toyMotivation", e.target.value as EnrichmentInput["toyMotivation"])}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </Field>

        <Field label="Mobility limitations">
          <select value={form.mobility} onChange={(e) => update("mobility", e.target.value as EnrichmentInput["mobility"])}>
            <option value="none">None known</option>
            <option value="mild">Mild</option>
            <option value="significant">Significant</option>
          </select>
        </Field>

        <Field label="Environment">
          <select value={form.environment} onChange={(e) => update("environment", e.target.value as EnrichmentInput["environment"])}>
            <option value="indoor">Indoor</option>
            <option value="outdoor">Outdoor</option>
            <option value="either">Either</option>
          </select>
        </Field>

        <Field label="Time available">
          <select value={form.minutes} onChange={(e) => update("minutes", e.target.value as EnrichmentInput["minutes"])}>
            <option value="10">About 10 minutes</option>
            <option value="20">About 20 minutes</option>
            <option value="40">About 40 minutes</option>
          </select>
        </Field>

        <button className="button" type="submit">Build today's plan</button>
      </form>

      <section className={styles.output} aria-live="polite">
        {!plan ? (
          <div className={styles.empty}>
            <p className="eyebrow">Today's Enrichment Plan</p>
            <h2>Tell us about the dog.</h2>
            <p>Your generated plan will appear here.</p>
          </div>
        ) : (
          <div className={styles.plan}>
            <p className="eyebrow">Today's Enrichment Plan</p>
            <h2>Simple. Useful. Adjustable.</h2>

            <PlanItem number="01" title="Warm-up" body={plan.warmup} />
            <PlanItem number="02" title="Main activity" body={plan.main} />
            <PlanItem number="03" title="Calming activity" body={plan.calming} />
            <PlanItem number="04" title="Optional challenge" body={plan.challenge} />

            <div className={styles.safety}>
              <strong>Safety considerations</strong>
              <ul>
                {plan.safety.map((item) => <li key={item}>{item}</li>)}
              </ul>
            </div>

            <button type="button" className="buttonGhost" onClick={printPlan}>
              Print this plan
            </button>
          </div>
        )}
      </section>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className={styles.field}>
      <span>{label}</span>
      {children}
    </label>
  );
}

function PlanItem({ number, title, body }: { number: string; title: string; body: string }) {
  return (
    <div className={styles.planItem}>
      <span>{number}</span>
      <div>
        <strong>{title}</strong>
        <p>{body}</p>
      </div>
    </div>
  );
}
