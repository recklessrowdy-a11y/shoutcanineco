"use client";

import { useMemo, useState } from "react";
import { interpretSignals, signalQuestions } from "@/lib/body-language";
import styles from "./DogTellingMeTool.module.css";

export function DogTellingMeTool() {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResult, setShowResult] = useState(false);

  const result = useMemo(() => interpretSignals(answers), [answers]);
  const complete = Object.keys(answers).length === signalQuestions.length;

  function choose(questionId: string, value: string) {
    setAnswers((current) => ({ ...current, [questionId]: value }));
    setShowResult(false);
  }

  function reset() {
    setAnswers({});
    setShowResult(false);
  }

  return (
    <div className={styles.tool}>
      <div className={styles.progress}>
        <span>{Object.keys(answers).length} / {signalQuestions.length} observations</span>
        <div>
          <i style={{ width: `${(Object.keys(answers).length / signalQuestions.length) * 100}%` }} />
        </div>
      </div>

      <div className={styles.questions}>
        {signalQuestions.map((question, index) => (
          <fieldset key={question.id}>
            <legend>
              <span>{String(index + 1).padStart(2, "0")}</span>
              {question.prompt}
            </legend>
            <div className={styles.options}>
              {question.options.map((option) => {
                const selected = answers[question.id] === option.key;
                return (
                  <button
                    type="button"
                    key={option.key}
                    aria-pressed={selected}
                    onClick={() => choose(question.id, option.key)}
                  >
                    {option.label}
                  </button>
                );
              })}
            </div>
          </fieldset>
        ))}
      </div>

      <div className={styles.actions}>
        <button
          type="button"
          className="button"
          disabled={!complete}
          onClick={() => setShowResult(true)}
        >
          Interpret this combination
        </button>
        <button type="button" className="buttonGhost" onClick={reset}>
          Reset
        </button>
      </div>

      {showResult && (
        <section className={styles.result} aria-live="polite">
          <p className="eyebrow">Educational interpretation</p>
          <h2>{result.title}</h2>
          <p>{result.summary}</p>

          <details>
            <summary>Review the observations you selected</summary>
            <ul>
              {result.observations.map((item) => <li key={item}>{item}</li>)}
            </ul>
          </details>

          <div className={styles.caution}>
            <strong>Important</strong>
            <p>{result.caution}</p>
          </div>
        </section>
      )}
    </div>
  );
}
