"use client";

import { useMemo, useState } from "react";
import { bodyLanguageSignals } from "@/lib/education";
import styles from "./BodyLanguageExplorer.module.css";

const states = [
  "Relaxed",
  "Interested",
  "Uncertain",
  "Stressed",
  "Fearful",
  "Defensive",
  "Highly aroused",
  "Playful"
] as const;

export function BodyLanguageExplorer() {
  const [selected, setSelected] = useState(bodyLanguageSignals[0].id);
  const [emotion, setEmotion] = useState<(typeof states)[number]>("Relaxed");

  const signal = useMemo(
    () => bodyLanguageSignals.find((item) => item.id === selected) ?? bodyLanguageSignals[0],
    [selected]
  );

  return (
    <div className={styles.shell}>
      <div className={styles.toolbar}>
        <div>
          <span>Emotional state</span>
          <select value={emotion} onChange={(e) => setEmotion(e.target.value as (typeof states)[number])}>
            {states.map((state) => <option key={state}>{state}</option>)}
          </select>
        </div>
        <p>
          Current demonstration: <strong>{emotion}</strong>
        </p>
      </div>

      <div className={styles.stage}>
        <div className={styles.figure} aria-label={`Illustrated dog body-language diagram showing ${emotion.toLowerCase()} state`}>
          <div className={styles.dog}>
            <div className={styles.earLeft} />
            <div className={styles.earRight} />
            <div className={styles.head}>
              <div className={styles.eye} />
              <div className={styles.muzzle} />
            </div>
            <div className={styles.body} />
            <div className={styles.legOne} />
            <div className={styles.legTwo} />
            <div className={styles.tail} />
          </div>

          {bodyLanguageSignals.map((item, index) => (
            <button
              key={item.id}
              className={`${styles.hotspot} ${styles[`hotspot${index + 1}`]}`}
              aria-pressed={selected === item.id}
              onClick={() => setSelected(item.id)}
            >
              {item.label}
            </button>
          ))}
        </div>

        <aside className={styles.panel}>
          <p className="eyebrow">{signal.label}</p>
          <h2>{signal.headline}</h2>
          <p>{signal.body}</p>
          <div className={styles.context}>
            <strong>Interpret in context</strong>
            <span>
              Combine this signal with body stiffness, movement, distance, environment,
              recent events, and the dog's individual baseline.
            </span>
          </div>
        </aside>
      </div>
    </div>
  );
}
