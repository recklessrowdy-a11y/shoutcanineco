# Shout Canine Co — Homepage Foundation

Production-oriented starter built with Next.js App Router + TypeScript.

## Run locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Included
- Responsive sticky header + mega navigation
- Editorial hero
- Choose Your Path segmentation
- Breed discovery grid
- Featured collection system
- Education feature
- Professional resources feature
- Meet Shout section
- Journal cards
- Community section
- Newsletter capture
- Responsive footer
- Reduced-motion accessibility support
- Reusable global design tokens and layout primitives

Replace the abstract art placeholders with licensed/owned Shout photography and product imagery when assets are ready.

## Phase 2 extension
- Breed Library index
- Dynamic breed hub route
- Siberian Husky + Doberman seed data
- Learn hub
- Education category route architecture
- Canine Body Language Center
- Interactive Body Language Explorer shell
- Reusable behavior article template
- Homepage/header links wired into the new architecture

### Key routes
- `/breeds`
- `/breeds/siberian-husky`
- `/breeds/doberman-pinscher`
- `/learn`
- `/learn/body-language`
- `/learn/body-language/explorer`
- `/learn/behavior`
- `/learn/behavior/sample-guide`

## Phase 3 extension
- Guided "What Is My Dog Telling Me?" questionnaire
- Deterministic body-language interpretation scoring
- Observation review + contextual safety disclaimer
- Enrichment Center
- Enrichment Generator with age, energy, motivation, mobility, environment, and time inputs
- Generated warm-up, main activity, calming activity, optional challenge, and safety considerations
- Print-friendly enrichment plan output

### New routes
- `/learn/body-language/what-is-my-dog-telling-me`
- `/learn/enrichment`
- `/learn/enrichment/generator`
