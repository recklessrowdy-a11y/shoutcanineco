export type EducationCategory = {
  slug: string;
  title: string;
  description: string;
};

export const educationCategories: EducationCategory[] = [
  { slug: "body-language", title: "Canine Body Language", description: "Read posture, facial tension, movement, distance, and context together." },
  { slug: "behavior", title: "Behavior", description: "Understand what behavior can communicate, what may influence it, and how management helps." },
  { slug: "enrichment", title: "Enrichment", description: "Build physical, mental, sensory, social, and species-typical outlets." },
  { slug: "dog-learning", title: "Dog Learning", description: "Explore reinforcement, motivation, repetition, environment, and skill-building." },
  { slug: "dog-play", title: "Dog Play", description: "Learn to notice reciprocity, pauses, consent checks, pressure, and escalation." },
  { slug: "health-safety", title: "Health & Safety", description: "Educational observation guides, warning signs, and clear boundaries around veterinary care." },
  { slug: "puppies", title: "Puppies", description: "Development, socialization, handling, learning, and age-appropriate expectations." },
  { slug: "senior-dogs", title: "Senior Dogs", description: "Support comfort, mobility, communication, enrichment, and changing needs." }
];

export const bodyLanguageSignals = [
  {
    id: "eyes",
    label: "Eyes",
    headline: "Eyes can show attention, tension, avoidance, and conflict.",
    body:
      "Notice eye shape, blinking, hard staring, gaze shifts, visible sclera, and what the dog is monitoring. Eye information matters most when combined with the rest of the body."
  },
  {
    id: "ears",
    label: "Ears",
    headline: "Ear position can shift with attention and emotional state.",
    body:
      "Forward, neutral, lateral, or pinned-back ears may all mean different things depending on breed anatomy, movement, posture, environment, and the dog's baseline."
  },
  {
    id: "mouth",
    label: "Mouth",
    headline: "The mouth often reveals changes in tension.",
    body:
      "Look for soft open-mouth breathing, lip tension, commissure changes, panting, lip licking, yawning, closed-mouth stillness, and vocalization."
  },
  {
    id: "tail",
    label: "Tail",
    headline: "A wagging tail does not automatically mean a happy dog.",
    body:
      "Consider height, stiffness, speed, range of motion, whole-body looseness, and breed-specific tail carriage. Tail information should never be interpreted alone."
  },
  {
    id: "posture",
    label: "Body Position",
    headline: "Weight distribution can reveal approach, retreat, uncertainty, or readiness.",
    body:
      "Notice forward weight, crouching, leaning away, freezing, curving, turning sideways, blocking, and whether the dog is increasing or decreasing distance."
  },
  {
    id: "movement",
    label: "Movement",
    headline: "Loose movement and stiff movement tell very different stories.",
    body:
      "Watch speed, rhythm, pauses, sudden stillness, exaggerated play gestures, displacement, pacing, and whether movement remains reciprocal in social interactions."
  }
];
