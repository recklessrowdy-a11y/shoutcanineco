export type SignalOption = {
  key: string;
  label: string;
  weight: {
    arousal?: number;
    distance?: number;
    uncertainty?: number;
    play?: number;
    relaxation?: number;
  };
};

export type SignalQuestion = {
  id: string;
  prompt: string;
  options: SignalOption[];
};

export const signalQuestions: SignalQuestion[] = [
  {
    id: "ears",
    prompt: "What are the ears doing?",
    options: [
      { key: "neutral", label: "Neutral / natural", weight: { relaxation: 2 } },
      { key: "forward", label: "Forward / highly oriented", weight: { arousal: 2 } },
      { key: "back", label: "Back or pinned", weight: { uncertainty: 2, distance: 1 } },
      { key: "shifting", label: "Rapidly shifting", weight: { uncertainty: 1, arousal: 1 } }
    ]
  },
  {
    id: "mouth",
    prompt: "What is the mouth doing?",
    options: [
      { key: "soft", label: "Soft / slightly open", weight: { relaxation: 2 } },
      { key: "closed", label: "Suddenly closed / tense", weight: { arousal: 1, uncertainty: 1 } },
      { key: "licking", label: "Lip licking / yawning", weight: { uncertainty: 2 } },
      { key: "vocal", label: "Growling / barking / vocalizing", weight: { arousal: 2, distance: 1 } }
    ]
  },
  {
    id: "weight",
    prompt: "Where is the dog's weight positioned?",
    options: [
      { key: "neutral", label: "Balanced / neutral", weight: { relaxation: 2 } },
      { key: "forward", label: "Forward", weight: { arousal: 2 } },
      { key: "back", label: "Leaning away / back", weight: { distance: 2, uncertainty: 2 } },
      { key: "crouched", label: "Crouched / lowered", weight: { uncertainty: 2, distance: 1 } }
    ]
  },
  {
    id: "body",
    prompt: "Is the body loose or stiff?",
    options: [
      { key: "loose", label: "Loose and wiggly", weight: { relaxation: 2, play: 1 } },
      { key: "still", label: "Still / frozen", weight: { arousal: 2, uncertainty: 2 } },
      { key: "stiff", label: "Stiff / rigid", weight: { arousal: 3 } },
      { key: "bouncy", label: "Bouncy / exaggerated", weight: { play: 3 } }
    ]
  },
  {
    id: "tail",
    prompt: "What is the tail doing?",
    options: [
      { key: "neutral", label: "Neutral carriage", weight: { relaxation: 2 } },
      { key: "high", label: "High and stiff", weight: { arousal: 2 } },
      { key: "low", label: "Low / tucked", weight: { uncertainty: 2, distance: 1 } },
      { key: "sweeping", label: "Broad, loose movement", weight: { relaxation: 1, play: 1 } }
    ]
  },
  {
    id: "distance",
    prompt: "Is the dog approaching or increasing distance?",
    options: [
      { key: "approaching", label: "Approaching directly", weight: { arousal: 1 } },
      { key: "curving", label: "Curving / approaching softly", weight: { relaxation: 1, play: 1 } },
      { key: "avoiding", label: "Turning away / increasing distance", weight: { distance: 3, uncertainty: 1 } },
      { key: "blocked", label: "Trying to leave but cannot", weight: { distance: 3, uncertainty: 2 } }
    ]
  },
  {
    id: "context",
    prompt: "What happened immediately before this behavior?",
    options: [
      { key: "nothing", label: "Nothing obvious / resting", weight: { relaxation: 1 } },
      { key: "social", label: "Dog or person approached", weight: { arousal: 1, uncertainty: 1 } },
      { key: "resource", label: "Food, toy, bed, or valued item was involved", weight: { arousal: 1, distance: 1 } },
      { key: "play", label: "Active play or chase", weight: { play: 2, arousal: 1 } }
    ]
  }
];

export type SignalResult = {
  title: string;
  summary: string;
  observations: string[];
  caution: string;
};

export function interpretSignals(answers: Record<string, string>): SignalResult {
  const totals = {
    arousal: 0,
    distance: 0,
    uncertainty: 0,
    play: 0,
    relaxation: 0
  };

  const observations: string[] = [];

  for (const question of signalQuestions) {
    const answer = answers[question.id];
    const option = question.options.find((o) => o.key === answer);
    if (!option) continue;

    observations.push(`${question.prompt.replace("?", "")}: ${option.label}`);
    for (const [key, value] of Object.entries(option.weight)) {
      totals[key as keyof typeof totals] += value ?? 0;
    }
  }

  const ranked = Object.entries(totals).sort((a, b) => b[1] - a[1]);
  const [top, score] = ranked[0];

  if (Object.keys(answers).length < 4) {
    return {
      title: "Not enough information yet",
      summary:
        "A few more observations will make this educational interpretation more useful.",
      observations,
      caution:
        "Behavior must be interpreted in context. This tool is educational and is not a behavioral diagnosis."
    };
  }

  const map: Record<string, { title: string; summary: string }> = {
    relaxation: {
      title: "This combination may be consistent with relative relaxation",
      summary:
        "Loose movement, neutral posture, and soft facial features can support a relaxed interpretation when the environment and the dog's baseline fit."
    },
    play: {
      title: "This combination may suggest playful intent",
      summary:
        "Bouncy movement, curved approaches, role changes, pauses, and loose gestures often support playful interpretations when both dogs can disengage."
    },
    uncertainty: {
      title: "This combination may indicate social uncertainty",
      summary:
        "Tension, lowered posture, pinned ears, lip licking, gaze shifts, or hesitation can occur when a dog is unsure about what is happening."
    },
    distance: {
      title: "Your dog may be trying to create distance",
      summary:
        "Turning away, leaning back, retreating, freezing, or attempting to leave can function as distance-increasing behavior."
    },
    arousal: {
      title: "Your dog may be showing increased arousal",
      summary:
        "Forward weight, stiffness, sudden stillness, intense orientation, or escalating vocal behavior can accompany higher arousal."
    }
  };

  const result = map[top];
  return {
    title: result.title,
    summary: `${result.summary} The strongest signal category in this response set scored ${score}.`,
    observations,
    caution:
      "Behavior must be interpreted in context. This tool is educational and is not a behavioral diagnosis. If there is a bite risk, sudden behavior change, or serious safety concern, involve an appropriate qualified professional and veterinarian."
  };
}
