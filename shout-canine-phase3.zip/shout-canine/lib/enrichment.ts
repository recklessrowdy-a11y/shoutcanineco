export type EnrichmentInput = {
  age: "puppy" | "adult" | "senior";
  energy: "low" | "medium" | "high";
  foodMotivation: "low" | "medium" | "high";
  toyMotivation: "low" | "medium" | "high";
  mobility: "none" | "mild" | "significant";
  environment: "indoor" | "outdoor" | "either";
  minutes: "10" | "20" | "40";
};

export type EnrichmentPlan = {
  warmup: string;
  main: string;
  calming: string;
  challenge: string;
  safety: string[];
};

const scentActivities = [
  "Scatter a small portion of the dog's normal food across a safe sniffing area.",
  "Create a simple scent trail using a few pieces of food with an easy jackpot at the end.",
  "Hide several easy-to-find treats or toys in one room and cue a calm search."
];

const nonFoodActivities = [
  "Set up a short object-search game using a favorite toy.",
  "Explore a novel but low-pressure walking route and allow generous sniffing time.",
  "Practice a short find-it game with a familiar object."
];

export function buildEnrichmentPlan(input: EnrichmentInput): EnrichmentPlan {
  const short = input.minutes === "10";
  const long = input.minutes === "40";
  const limited = input.mobility !== "none" || input.age === "senior";

  const warmup = limited
    ? "Begin with 2–3 minutes of slow sniffing and easy movement on a non-slip surface."
    : input.energy === "high"
      ? "Begin with 3–5 minutes of calm sniffing before adding more active work."
      : "Begin with a brief decompression sniff or easy orientation game.";

  let main = input.foodMotivation !== "low"
    ? scentActivities[input.energy === "high" ? 1 : input.age === "puppy" ? 2 : 0]
    : nonFoodActivities[input.toyMotivation === "high" ? 0 : 1];

  if (limited) {
    main =
      "Use a low-impact scent-search setup at nose level with easy stations, stable footing, and no jumping or tight turns.";
  } else if (input.environment === "outdoor" && input.energy === "high") {
    main =
      "Create a supervised outdoor search route with several scent stations, brief movement between stations, and built-in pauses.";
  } else if (input.age === "puppy") {
    main =
      "Use a short novelty-and-search session with easy textures, safe objects, and frequent pauses. Keep difficulty low enough for repeated success.";
  }

  const calming = limited
    ? "Finish with quiet sniffing, a lickable food activity if appropriate, or relaxed observation in a comfortable location."
    : "Finish with a lower-arousal activity such as scatter feeding, slow sniffing, licking, or quiet observation.";

  const challenge = short
    ? "Optional challenge: change one hiding location or add one slightly harder search."
    : long
      ? "Optional challenge: run a second round with a new search area, then add a 2–3 minute simple training game."
      : "Optional challenge: add one new hiding place, surface, or cue while keeping the success rate high.";

  const safety = [
    "Supervise new enrichment activities.",
    "Use items too large to swallow and remove damaged toys or containers.",
    "Adjust food portions to account for enrichment calories.",
    "Stop if the dog shows distress, frustration that is escalating, pain, or unsafe behavior."
  ];

  if (input.mobility !== "none") {
    safety.push("Avoid jumping, slippery floors, repeated stairs, sharp turns, and other movements that may aggravate mobility limitations.");
  }
  if (input.age === "puppy") {
    safety.push("Keep sessions brief and developmentally appropriate; avoid forced exercise or overwhelming novelty.");
  }
  if (input.age === "senior") {
    safety.push("Prioritize traction, comfort, easy access, and veterinary guidance for known medical or mobility concerns.");
  }

  return { warmup, main, calming, challenge, safety };
}
