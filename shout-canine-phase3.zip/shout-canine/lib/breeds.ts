export type Breed = {
  slug: string;
  name: string;
  group: string;
  intro: string;
  traits: string[];
  communication: string[];
  enrichment: string[];
  misconceptions: string[];
  handling: string[];
  grooming: string[];
  history: string;
  relatedArticles: { title: string; href: string }[];
};

export const breeds: Breed[] = [
  {
    slug: "siberian-husky",
    name: "Siberian Husky",
    group: "Working Dog",
    intro:
      "Independent, expressive, athletic, and famously opinionated. Siberian Huskies combine endurance, social intelligence, persistence, and a strong capacity for making their own decisions.",
    traits: ["Athletic", "Social", "Independent", "Vocal", "Persistent", "Curious"],
    communication: [
      "Often expressive through vocalization and movement",
      "Can use distance and body orientation very clearly",
      "May appear socially confident while still needing choice and space"
    ],
    enrichment: [
      "Scent work and search games",
      "Novel walking routes",
      "Food puzzles",
      "Safe running and pulling outlets",
      "Short training sessions with clear reinforcement"
    ],
    misconceptions: [
      "Independence does not mean a dog is incapable of learning",
      "Vocal behavior is not automatically defiance",
      "Escape behavior is usually more complex than simple stubbornness"
    ],
    handling: [
      "Use secure equipment and thoughtful management",
      "Avoid creating unnecessary conflict around restraint",
      "Build cooperative handling through reinforcement and predictability"
    ],
    grooming: [
      "Expect seasonal coat blow",
      "Brush through the undercoat without damaging guard hairs",
      "Avoid shaving unless medically necessary"
    ],
    history:
      "Developed as endurance sled dogs, Siberian Huskies were selected for stamina, efficient movement, social cooperation, and the ability to work in demanding northern environments.",
    relatedArticles: [
      { title: "Why Huskies Are So Vocal", href: "/learn/behavior/why-huskies-are-vocal" },
      { title: "Understanding Independent Breeds", href: "/learn/dog-learning/independent-breeds" },
      { title: "Husky Enrichment Ideas", href: "/learn/enrichment/husky-enrichment" }
    ]
  },
  {
    slug: "doberman-pinscher",
    name: "Doberman Pinscher",
    group: "Working Dog",
    intro:
      "Athletic, observant, people-oriented, and highly responsive to their environment. Dobermans often combine sensitivity with intensity and benefit from clear, thoughtful handling.",
    traits: ["Observant", "Athletic", "Sensitive", "People-oriented", "Fast-learning"],
    communication: [
      "Postural changes can be subtle and fast",
      "Stiffness and forward weight shifts deserve attention",
      "Many individuals stay closely tuned to their handler"
    ],
    enrichment: [
      "Structured movement",
      "Training games",
      "Search tasks",
      "Tug with rules and pauses",
      "Problem-solving activities"
    ],
    misconceptions: [
      "Confidence and sensitivity can exist in the same dog",
      "Alert behavior is not the same as indiscriminate aggression"
    ],
    handling: [
      "Prioritize clarity and consistency",
      "Avoid escalating arousal unnecessarily",
      "Use consent-based cooperative care where possible"
    ],
    grooming: [
      "Short coats still benefit from routine skin and nail care",
      "Monitor pressure points and skin condition"
    ],
    history:
      "Developed in Germany as a versatile personal protection and working dog, the Doberman Pinscher was shaped for athleticism, alertness, responsiveness, and close partnership with people.",
    relatedArticles: [
      { title: "Reading Body Stiffness", href: "/learn/body-language/body-stiffness" },
      { title: "Understanding Arousal", href: "/learn/body-language/arousal" }
    ]
  }
];

export function getBreed(slug: string) {
  return breeds.find((breed) => breed.slug === slug);
}
