import { notFound } from "next/navigation";
import Link from "next/link";
import { breeds, getBreed } from "@/lib/breeds";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

export function generateStaticParams() {
  return breeds.map((breed) => ({ breed: breed.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ breed: string }> }) {
  const { breed: slug } = await params;
  const breed = getBreed(slug);
  if (!breed) return {};
  return {
    title: `${breed.name} Guide`,
    description: `${breed.name} traits, communication, enrichment, handling, grooming, history, and related canine education.`
  };
}

function ListSection({
  title,
  items
}: {
  title: string;
  items: string[];
}) {
  return (
    <section className={styles.infoSection}>
      <h2>{title}</h2>
      <ul>
        {items.map((item) => <li key={item}>{item}</li>)}
      </ul>
    </section>
  );
}

export default async function BreedPage({ params }: { params: Promise<{ breed: string }> }) {
  const { breed: slug } = await params;
  const breed = getBreed(slug);
  if (!breed) notFound();

  return (
    <>
      <Header />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">{breed.group}</p>
            <h1>{breed.name}</h1>
            <p>{breed.intro}</p>
            <div className={styles.traits}>
              {breed.traits.map((trait) => <span key={trait}>{trait}</span>)}
            </div>
          </div>
        </section>

        <section className="section">
          <div className={`container ${styles.layout}`}>
            <div className={styles.main}>
              <section className={styles.infoSection}>
                <h2>Historical purpose</h2>
                <p>{breed.history}</p>
              </section>

              <ListSection title={`${breed.name} communication`} items={breed.communication} />
              <ListSection title="Enrichment ideas" items={breed.enrichment} />
              <ListSection title="Common misconceptions" items={breed.misconceptions} />
              <ListSection title="Handling considerations" items={breed.handling} />
              <ListSection title="Grooming considerations" items={breed.grooming} />

              <section className={styles.infoSection}>
                <h2>Related education</h2>
                <div className={styles.related}>
                  {breed.relatedArticles.map((article) => (
                    <Link href={article.href} key={article.href}>{article.title} →</Link>
                  ))}
                </div>
              </section>
            </div>

            <aside className={styles.aside}>
              <div>
                <p className="eyebrow">Breed note</p>
                <h3>Breed informs. The individual decides.</h3>
                <p>
                  Genetics, learning history, health, environment, age, reinforcement,
                  and individual temperament all shape behavior.
                </p>
              </div>
              <div>
                <p className="eyebrow">Shop this breed</p>
                <h3>{breed.name} goods</h3>
                <p>Connect this panel to Shopify collections when commerce data is wired in.</p>
                <Link className="textLink" href="#">View products</Link>
              </div>
            </aside>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
