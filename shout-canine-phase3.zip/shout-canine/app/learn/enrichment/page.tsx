import Link from "next/link";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

const categories = [
  ["Physical", "Movement appropriate to the dog's age, health, ability, and preferences."],
  ["Mental", "Problem-solving, learning, puzzles, and structured cognitive work."],
  ["Sensory", "Sniffing, textures, sounds, observation, exploration, and novelty."],
  ["Social", "Appropriate interaction with people or compatible dogs when the dog enjoys it."],
  ["Species-typical", "Searching, shredding, chewing, digging, sniffing, carrying, and other normal canine behaviors."]
];

export default function EnrichmentPage() {
  return (
    <>
      <Header />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">Enrichment Center</p>
            <h1>Enrichment Is More Than Exercise</h1>
            <p>
              Good enrichment gives dogs safe opportunities to use their bodies, senses,
              brains, preferences, and species-typical behavior.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.grid}>
              {categories.map(([title, copy]) => (
                <article key={title}>
                  <h2>{title}</h2>
                  <p>{copy}</p>
                </article>
              ))}
            </div>

            <div className={styles.generator}>
              <div>
                <p className="eyebrow">Interactive tool</p>
                <h2>Tell us about the dog.</h2>
                <p>
                  Build a plan using age, energy, food and toy motivation,
                  mobility, environment, and time available.
                </p>
              </div>
              <Link className="button" href="/learn/enrichment/generator">Open Enrichment Generator</Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
