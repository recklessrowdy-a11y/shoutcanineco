import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

const sections = [
  ["What It Looks Like", "Describe the observable behavior without assigning motive first."],
  ["Why It May Happen", "Consider learning history, environment, reinforcement, health, fear, frustration, arousal, access, and context."],
  ["What the Dog May Be Communicating", "Frame possibilities carefully and avoid claiming certainty from a single behavior."],
  ["Common Triggers", "List repeatable environmental or social events that may precede the behavior."],
  ["What Often Makes It Worse", "Identify pressure, repetition, flooding, conflict, unpredictable handling, or accidental reinforcement."],
  ["Management", "Reduce rehearsal, increase safety, and change the environment before expecting new behavior."],
  ["Training Considerations", "Build skills gradually with appropriate reinforcement, distance, and difficulty."],
  ["When Professional Help Is Appropriate", "Escalating aggression, safety risk, severe fear, sudden behavior change, or complex cases may require qualified professional and/or veterinary support."],
  ["Related Topics", "Connect readers into the wider Shout Canine Co education ecosystem."]
];

export default function SampleGuidePage() {
  return (
    <>
      <Header />
      <main>
        <article>
          <header className={styles.hero}>
            <div className="container">
              <p className="eyebrow">Behavior Guide Template</p>
              <h1>Example Behavior Guide Structure</h1>
              <p>
                A reusable editorial template for consistent, readable, internally linked canine behavior content.
              </p>
            </div>
          </header>

          <div className={`container ${styles.layout}`}>
            <nav className={styles.toc} aria-label="Article contents">
              <strong>On this page</strong>
              {sections.map(([title], index) => (
                <a href={`#section-${index}`} key={title}>{title}</a>
              ))}
            </nav>

            <div className={styles.content}>
              <div className={styles.answer}>
                <strong>Short answer</strong>
                <p>
                  Start with what can be observed, consider context and history, and avoid reducing behavior to a single label.
                </p>
              </div>

              {sections.map(([title, body], index) => (
                <section id={`section-${index}`} key={title}>
                  <h2>{title}</h2>
                  <p>{body}</p>
                </section>
              ))}
            </div>
          </div>
        </article>
      </main>
      <Footer />
    </>
  );
}
