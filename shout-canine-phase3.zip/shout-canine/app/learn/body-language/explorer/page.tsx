import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { BodyLanguageExplorer } from "@/components/interactive/BodyLanguageExplorer";

export const metadata = {
  title: "Interactive Dog Body Language Explorer",
  description:
    "Explore canine eyes, ears, mouth, tail, posture, and movement in context with an interactive educational body-language tool."
};

export default function ExplorerPage() {
  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className="container">
            <p className="eyebrow">Interactive education</p>
            <h1 className="sectionTitle">Dog Body Language Explorer</h1>
            <p className="sectionLead">
              Click different body areas and compare signals. This tool is educational and is not a behavioral diagnosis.
            </p>
            <div style={{ marginTop: 36 }}>
              <BodyLanguageExplorer />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
