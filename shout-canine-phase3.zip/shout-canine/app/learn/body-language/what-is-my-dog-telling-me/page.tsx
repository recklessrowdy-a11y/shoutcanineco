import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { DogTellingMeTool } from "@/components/interactive/DogTellingMeTool";

export const metadata = {
  title: "What Is My Dog Telling Me?",
  description:
    "Use a guided educational questionnaire to consider canine ears, mouth, posture, tail, movement, distance, and context together."
};

export default function DogTellingMePage() {
  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className="container">
            <p className="eyebrow">Guided body-language tool</p>
            <h1 className="sectionTitle">What Is My Dog Telling Me?</h1>
            <p className="sectionLead">
              Choose the observations that best match what you see. The result describes
              educational possibilities—not a diagnosis or certainty about your dog's emotional state.
            </p>

            <div style={{ marginTop: 42 }}>
              <DogTellingMeTool />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
