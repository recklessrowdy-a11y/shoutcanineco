import { notFound } from "next/navigation";
import Link from "next/link";
import { educationCategories } from "@/lib/education";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

export function generateStaticParams() {
  return educationCategories
    .filter((item) => item.slug !== "body-language")
    .map((category) => ({ category: category.slug }));
}

export default async function EducationCategoryPage({
  params
}: {
  params: Promise<{ category: string }>
}) {
  const { category: slug } = await params;
  const category = educationCategories.find((item) => item.slug === slug);

  if (!category || slug === "body-language") notFound();

  return (
    <>
      <Header />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">Learn</p>
            <h1>{category.title}</h1>
            <p>{category.description}</p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.intro}>
              <p className="eyebrow">Content architecture ready</p>
              <h2>Consistent, searchable guides.</h2>
              <p>
                This category is scaffolded for article pages using the Shout Canine Co guide structure:
                what it looks like, why it may happen, what the dog may be communicating, triggers,
                what can make it worse, management, training considerations, professional help, and related topics.
              </p>
              <Link className="textLink" href="/learn">Back to Learn</Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
