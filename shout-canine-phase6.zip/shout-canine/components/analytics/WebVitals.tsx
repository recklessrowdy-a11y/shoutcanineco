"use client";

import { useReportWebVitals } from "next/web-vitals";

type Metric = Parameters<typeof useReportWebVitals>[0] extends (metric: infer M) => void ? M : never;

function reportMetric(metric: Metric) {
  const value = Math.round(metric.name === "CLS" ? metric.value * 1000 : metric.value);

  window.dispatchEvent(
    new CustomEvent("shout:analytics", {
      detail: {
        name: metric.name,
        params: {
          value,
          metric_id: metric.id,
          metric_delta: metric.delta,
          non_interaction: true
        }
      }
    })
  );
}

export function WebVitals() {
  useReportWebVitals(reportMetric);
  return null;
}
