"use client";

import { useState } from "react";
import styles from "./AddToCart.module.css";

export function AddToCart({
  merchandiseId,
  available
}: {
  merchandiseId: string;
  available: boolean;
}) {
  const [state, setState] = useState<"idle" | "adding" | "added" | "error">("idle");
  const [message, setMessage] = useState("");

  async function add() {
    if (!available || state === "adding") return;
    setState("adding");
    setMessage("");

    try {
      const response = await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ merchandiseId, quantity: 1 })
      });
      const payload = await response.json();

      if (!response.ok) throw new Error(payload.error || "Unable to add item.");

      setState("added");
      setMessage("Added to bag.");
      window.dispatchEvent(new CustomEvent("shout:cart-updated", { detail: payload.cart }));
      window.dispatchEvent(new CustomEvent("shout:analytics", {
        detail: { name: "add_to_cart", params: { merchandise_id: merchandiseId } }
      }));
    } catch (error) {
      setState("error");
      setMessage(error instanceof Error ? error.message : "Unable to add item.");
    }
  }

  return (
    <div className={styles.wrap}>
      <button className="button" type="button" onClick={add} disabled={!available || state === "adding"}>
        {!available ? "Sold out" : state === "adding" ? "Adding…" : state === "added" ? "Added" : "Add to bag"}
      </button>
      {message && <span aria-live="polite" className={state === "error" ? styles.error : ""}>{message}</span>}
    </div>
  );
}
