"use client";

import { useEffect, useState } from "react";
import styles from "./CartButton.module.css";

type CartLine = {
  id: string;
  quantity: number;
  merchandise: {
    id: string;
    title: string;
    product: { title: string; handle: string };
    price: { amount: string; currencyCode: string };
  };
};

type Cart = {
  id: string;
  totalQuantity: number;
  checkoutUrl: string;
  cost: {
    subtotalAmount: { amount: string; currencyCode: string };
    totalAmount: { amount: string; currencyCode: string };
  };
  lines: { nodes: CartLine[] };
};

function money(amount: string, currencyCode: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currencyCode
  }).format(Number(amount));
}

export function CartButton() {
  const [cart, setCart] = useState<Cart | null>(null);
  const [open, setOpen] = useState(false);
  const [busyLine, setBusyLine] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  async function refresh() {
    try {
      const response = await fetch("/api/cart", { cache: "no-store" });
      const payload = await response.json();
      setCart(payload.cart || null);
    } catch {
      setCart(null);
    }
  }

  async function changeLine(lineId: string, quantity: number) {
    setBusyLine(lineId);
    setMessage("");
    try {
      const response = await fetch("/api/cart", {
        method: quantity === 0 ? "DELETE" : "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(quantity === 0 ? { lineId } : { lineId, quantity })
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Unable to update bag.");
      setCart(payload.cart || null);
      window.dispatchEvent(new CustomEvent("shout:cart-updated", { detail: payload.cart }));
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to update bag.");
    } finally {
      setBusyLine(null);
    }
  }

  useEffect(() => {
    refresh();
    const handler = (event: Event) => {
      const custom = event as CustomEvent<Cart>;
      setCart(custom.detail || null);
      setOpen(true);
    };
    const escape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };

    window.addEventListener("shout:cart-updated", handler);
    window.addEventListener("keydown", escape);
    return () => {
      window.removeEventListener("shout:cart-updated", handler);
      window.removeEventListener("keydown", escape);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} aria-haspopup="dialog" aria-expanded={open}>
        Bag {cart?.totalQuantity ?? 0}
      </button>

      {open && (
        <div className={styles.backdrop} role="presentation" onMouseDown={() => setOpen(false)}>
          <section
            className={styles.drawer}
            role="dialog"
            aria-modal="true"
            aria-label="Shopping bag"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className={styles.top}>
              <strong>Shopping bag</strong>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close shopping bag">Close</button>
            </div>

            <div className={styles.body}>
              {cart?.totalQuantity ? (
                <>
                  <div className={styles.lines}>
                    {cart.lines.nodes.map((line) => (
                      <article key={line.id} className={styles.line}>
                        <div>
                          <strong>{line.merchandise.product.title}</strong>
                          <span>{line.merchandise.title}</span>
                          <span>
                            {money(line.merchandise.price.amount, line.merchandise.price.currencyCode)} each
                          </span>
                        </div>
                        <div className={styles.quantity}>
                          <button
                            type="button"
                            disabled={busyLine === line.id}
                            aria-label={`Decrease ${line.merchandise.product.title} quantity`}
                            onClick={() => changeLine(line.id, Math.max(0, line.quantity - 1))}
                          >
                            −
                          </button>
                          <span aria-label="Quantity">{line.quantity}</span>
                          <button
                            type="button"
                            disabled={busyLine === line.id || line.quantity >= 50}
                            aria-label={`Increase ${line.merchandise.product.title} quantity`}
                            onClick={() => changeLine(line.id, line.quantity + 1)}
                          >
                            +
                          </button>
                          <button
                            type="button"
                            disabled={busyLine === line.id}
                            onClick={() => changeLine(line.id, 0)}
                          >
                            Remove
                          </button>
                        </div>
                      </article>
                    ))}
                  </div>

                  <div className={styles.total}>
                    <span>Subtotal</span>
                    <strong>
                      {money(cart.cost.subtotalAmount.amount, cart.cost.subtotalAmount.currencyCode)}
                    </strong>
                  </div>

                  {message && <p className={styles.error} aria-live="polite">{message}</p>}

                  <a
                    className="button"
                    href={cart.checkoutUrl}
                    onClick={() => {
                      window.dispatchEvent(new CustomEvent("shout:analytics", {
                        detail: { name: "begin_checkout", params: { quantity: cart.totalQuantity } }
                      }));
                    }}
                  >
                    Secure checkout
                  </a>
                </>
              ) : (
                <>
                  <h2>Your bag is empty.</h2>
                  <p>Browse the shop and add a live Shopify variant when commerce is configured.</p>
                  <a className="buttonGhost" href="/shop">Explore shop</a>
                </>
              )}
            </div>
          </section>
        </div>
      )}
    </>
  );
}
