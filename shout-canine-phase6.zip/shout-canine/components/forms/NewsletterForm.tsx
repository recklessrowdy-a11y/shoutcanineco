"use client";

import { FormEvent, useState } from "react";

export function NewsletterForm() {
  const [state, setState] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") || "");
    setState("sending");
    setMessage("");

    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, source: "footer-newsletter" })
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Unable to subscribe.");

      setState("success");
      setMessage("You're in the pack.");
      event.currentTarget.reset();
      window.dispatchEvent(new CustomEvent("shout:analytics", {
        detail: { name: "newsletter_signup", params: { source: "footer-newsletter" } }
      }));
    } catch (error) {
      setState("error");
      setMessage(error instanceof Error ? error.message : "Unable to subscribe.");
    }
  }

  return (
    <form onSubmit={submit}>
      <label htmlFor="newsletter-email">Email address</label>
      <div>
        <input
          id="newsletter-email"
          name="email"
          type="email"
          placeholder="you@example.com"
          autoComplete="email"
          required
        />
        <button type="submit" disabled={state === "sending"}>
          {state === "sending" ? "Joining…" : "Join the Pack"}
        </button>
      </div>
      <small aria-live="polite">
        {message || "Educational content only. Unsubscribe anytime."}
      </small>
    </form>
  );
}
