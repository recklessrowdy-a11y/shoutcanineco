import styles from "./Newsletter.module.css";
import { NewsletterForm } from "@/components/forms/NewsletterForm";

export function Newsletter() {
  return (
    <section className={`${styles.section} section`}>
      <div className="container">
        <div className={styles.box}>
          <div>
            <p className="eyebrow">Learn something useful every week</p>
            <h2>Better dog knowledge. No discount-wheel nonsense.</h2>
            <p>
              Canine behavior insights, breed guides, enrichment ideas,
              new resources, and Shout Canine Co releases.
            </p>
          </div>
          <div className={styles.form}>
            <NewsletterForm />
          </div>
        </div>
      </div>
    </section>
  );
}
