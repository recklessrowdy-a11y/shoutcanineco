import "server-only";

const API_VERSION = process.env.SHOPIFY_STOREFRONT_API_VERSION || "2026-07";
const STORE_DOMAIN = process.env.SHOPIFY_STORE_DOMAIN;
const PUBLIC_TOKEN = process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN;
const PRIVATE_TOKEN = process.env.SHOPIFY_STOREFRONT_PRIVATE_TOKEN;

export type ShopifyMoney = {
  amount: string;
  currencyCode: string;
};

export type ShopifyVariant = {
  id: string;
  title: string;
  availableForSale: boolean;
  price: ShopifyMoney;
};

export type ShopifyProduct = {
  id: string;
  handle: string;
  title: string;
  description: string;
  featuredImage: null | {
    url: string;
    altText: string | null;
    width: number | null;
    height: number | null;
  };
  variants: {
    nodes: ShopifyVariant[];
  };
};

type StorefrontResponse<T> = {
  data?: T;
  errors?: { message: string }[];
};

export function isShopifyConfigured() {
  return Boolean(STORE_DOMAIN && (PUBLIC_TOKEN || PRIVATE_TOKEN));
}

function storefrontEndpoint() {
  if (!STORE_DOMAIN) throw new Error("SHOPIFY_STORE_DOMAIN is not configured.");
  const domain = STORE_DOMAIN.replace(/^https?:\/\//, "").replace(/\/$/, "");
  return `https://${domain}/api/${API_VERSION}/graphql.json`;
}

export async function storefrontFetch<T>(
  query: string,
  variables: Record<string, unknown> = {},
  options?: {
    buyerIp?: string | null;
    cache?: RequestCache;
    tags?: string[];
  }
): Promise<T> {
  if (!isShopifyConfigured()) {
    throw new Error("Shopify Storefront API is not configured.");
  }

  const headers: Record<string, string> = {
    "Content-Type": "application/json"
  };

  if (PRIVATE_TOKEN) {
    headers["Shopify-Storefront-Private-Token"] = PRIVATE_TOKEN;
    if (options?.buyerIp) {
      headers["Shopify-Storefront-Buyer-IP"] = options.buyerIp;
    }
  } else if (PUBLIC_TOKEN) {
    headers["X-Shopify-Storefront-Access-Token"] = PUBLIC_TOKEN;
  }

  const response = await fetch(storefrontEndpoint(), {
    method: "POST",
    headers,
    body: JSON.stringify({ query, variables }),
    cache: options?.cache ?? "no-store",
    next: options?.tags ? { tags: options.tags } : undefined
  });

  if (!response.ok) {
    throw new Error(`Shopify Storefront request failed (${response.status}).`);
  }

  const payload = (await response.json()) as StorefrontResponse<T>;

  if (payload.errors?.length) {
    throw new Error(payload.errors.map((error) => error.message).join("; "));
  }

  if (!payload.data) {
    throw new Error("Shopify Storefront API returned no data.");
  }

  return payload.data;
}

const PRODUCT_BY_HANDLE = `
  query ProductByHandle($handle: String!) {
    product(handle: $handle) {
      id
      handle
      title
      description
      featuredImage {
        url
        altText
        width
        height
      }
      variants(first: 50) {
        nodes {
          id
          title
          availableForSale
          price {
            amount
            currencyCode
          }
        }
      }
    }
  }
`;

export async function getShopifyProduct(handle: string): Promise<ShopifyProduct | null> {
  if (!isShopifyConfigured()) return null;

  const data = await storefrontFetch<{ product: ShopifyProduct | null }>(
    PRODUCT_BY_HANDLE,
    { handle },
    { cache: "force-cache", tags: [`shopify-product:${handle}`] }
  );

  return data.product;
}

export type CartLine = {
  id: string;
  quantity: number;
  merchandise: {
    id: string;
    title: string;
    product: {
      title: string;
      handle: string;
    };
    price: ShopifyMoney;
  };
};

export type ShopifyCart = {
  id: string;
  checkoutUrl: string;
  totalQuantity: number;
  cost: {
    subtotalAmount: ShopifyMoney;
    totalAmount: ShopifyMoney;
  };
  lines: {
    nodes: CartLine[];
  };
};

const CART_FIELDS = `
  fragment CartFields on Cart {
    id
    checkoutUrl
    totalQuantity
    cost {
      subtotalAmount { amount currencyCode }
      totalAmount { amount currencyCode }
    }
    lines(first: 100) {
      nodes {
        id
        quantity
        merchandise {
          ... on ProductVariant {
            id
            title
            price { amount currencyCode }
            product { title handle }
          }
        }
      }
    }
  }
`;

export async function getCart(cartId: string, buyerIp?: string | null) {
  const data = await storefrontFetch<{ cart: ShopifyCart | null }>(
    `query Cart($id: ID!) { cart(id: $id) { ...CartFields } } ${CART_FIELDS}`,
    { id: cartId },
    { buyerIp }
  );
  return data.cart;
}

export async function createCart(
  merchandiseId: string,
  quantity: number,
  buyerIp?: string | null
) {
  const data = await storefrontFetch<{
    cartCreate: {
      cart: ShopifyCart | null;
      userErrors: { field: string[] | null; message: string }[];
    };
  }>(
    `mutation CartCreate($input: CartInput) {
      cartCreate(input: $input) {
        cart { ...CartFields }
        userErrors { field message }
      }
    }
    ${CART_FIELDS}`,
    {
      input: {
        lines: [{ merchandiseId, quantity }]
      }
    },
    { buyerIp }
  );

  if (data.cartCreate.userErrors.length) {
    throw new Error(data.cartCreate.userErrors.map((e) => e.message).join("; "));
  }
  if (!data.cartCreate.cart) throw new Error("Shopify did not return a cart.");
  return data.cartCreate.cart;
}

export async function addCartLines(
  cartId: string,
  merchandiseId: string,
  quantity: number,
  buyerIp?: string | null
) {
  const data = await storefrontFetch<{
    cartLinesAdd: {
      cart: ShopifyCart | null;
      userErrors: { field: string[] | null; message: string }[];
    };
  }>(
    `mutation CartLinesAdd($cartId: ID!, $lines: [CartLineInput!]!) {
      cartLinesAdd(cartId: $cartId, lines: $lines) {
        cart { ...CartFields }
        userErrors { field message }
      }
    }
    ${CART_FIELDS}`,
    { cartId, lines: [{ merchandiseId, quantity }] },
    { buyerIp }
  );

  if (data.cartLinesAdd.userErrors.length) {
    throw new Error(data.cartLinesAdd.userErrors.map((e) => e.message).join("; "));
  }
  if (!data.cartLinesAdd.cart) throw new Error("Shopify did not return the updated cart.");
  return data.cartLinesAdd.cart;
}

export async function updateCartLine(
  cartId: string,
  lineId: string,
  quantity: number,
  buyerIp?: string | null
) {
  const data = await storefrontFetch<{
    cartLinesUpdate: {
      cart: ShopifyCart | null;
      userErrors: { field: string[] | null; message: string }[];
    };
  }>(
    `mutation CartLinesUpdate($cartId: ID!, $lines: [CartLineUpdateInput!]!) {
      cartLinesUpdate(cartId: $cartId, lines: $lines) {
        cart { ...CartFields }
        userErrors { field message }
      }
    }
    ${CART_FIELDS}`,
    { cartId, lines: [{ id: lineId, quantity }] },
    { buyerIp }
  );

  if (data.cartLinesUpdate.userErrors.length) {
    throw new Error(data.cartLinesUpdate.userErrors.map((e) => e.message).join("; "));
  }
  if (!data.cartLinesUpdate.cart) throw new Error("Shopify did not return the updated cart.");
  return data.cartLinesUpdate.cart;
}

export async function removeCartLine(
  cartId: string,
  lineId: string,
  buyerIp?: string | null
) {
  const data = await storefrontFetch<{
    cartLinesRemove: {
      cart: ShopifyCart | null;
      userErrors: { field: string[] | null; message: string }[];
    };
  }>(
    `mutation CartLinesRemove($cartId: ID!, $lineIds: [ID!]!) {
      cartLinesRemove(cartId: $cartId, lineIds: $lineIds) {
        cart { ...CartFields }
        userErrors { field message }
      }
    }
    ${CART_FIELDS}`,
    { cartId, lineIds: [lineId] },
    { buyerIp }
  );

  if (data.cartLinesRemove.userErrors.length) {
    throw new Error(data.cartLinesRemove.userErrors.map((e) => e.message).join("; "));
  }
  if (!data.cartLinesRemove.cart) throw new Error("Shopify did not return the updated cart.");
  return data.cartLinesRemove.cart;
}
