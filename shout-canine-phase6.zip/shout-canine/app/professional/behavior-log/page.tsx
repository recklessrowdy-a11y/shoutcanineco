import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { BehaviorLogBuilder } from "@/components/professional/BehaviorLogBuilder";

export const metadata = {
  title: "Build a Dog Behavior Log",
  description:
    "Create and print a structured dog behavior record with environment, trigger, observed behavior, intensity, handler response, recovery, and notes."
};

export default function BehaviorLogPage() {
  return (
    <>
      <Header />
      <main id="main-content">
        <section className="section">
          <div className="container">
            <p className="eyebrow">Professional toolkit</p>
            <h1 className="sectionTitle">Build a Dog Behavior Log</h1>
            <p className="sectionLead">
              Document what happened in observable terms so teams can compare patterns, responses, and recovery over time.
            </p>
            <div style={{ marginTop: 40 }}>
              <BehaviorLogBuilder />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
