import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { GroupPlayCompatibility } from "@/components/professional/GroupPlayCompatibility";

export const metadata = {
  title: "Group Play Compatibility Worksheet",
  description:
    "Organize play style, energy, arousal, social confidence, resource concerns, barrier behavior, and handling observations for group-care planning."
};

export default function GroupPlayCompatibilityPage() {
  return (
    <>
      <Header />
      <main id="main-content">
        <section className="section">
          <div className="container">
            <p className="eyebrow">Professional toolkit</p>
            <h1 className="sectionTitle">Group Play Compatibility Worksheet</h1>
            <p className="sectionLead">
              Organize factors that matter in group care. This tool provides management guidance—not a guarantee that dogs are compatible.
            </p>
            <div style={{ marginTop: 40 }}>
              <GroupPlayCompatibility />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
