"use client";

export default function ErrorPage({
  reset
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="statusPage">
      <div>
        <p className="eyebrow">Something went wrong</p>
        <h1>We lost the scent.</h1>
        <p>The page hit an unexpected error. You can retry without losing the rest of the site.</p>
        <button className="button" type="button" onClick={reset}>Try again</button>
      </div>
    </main>
  );
}
