export default function Loading() {
  return (
    <main className="statusPage" aria-busy="true" aria-live="polite">
      <div>
        <p className="eyebrow">Loading</p>
        <h1>Following the trail…</h1>
      </div>
    </main>
  );
}
