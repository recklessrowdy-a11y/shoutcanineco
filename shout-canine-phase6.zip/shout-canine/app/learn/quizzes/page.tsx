import Link from "next/link";
import { quizzes } from "@/lib/quizzes";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

export default function QuizzesPage() {
  return (
    <>
      <Header />
      <main id="main-content">
        <section className="section">
          <div className="container">
            <p className="eyebrow">Test Your Dog Knowledge</p>
            <h1 className="sectionTitle">Learn by noticing.</h1>
            <p className="sectionLead">
              Short interactive quizzes built to reinforce observation, context, and practical canine knowledge.
            </p>

            <div className={styles.grid}>
              {quizzes.map((quiz) => (
                <Link href={`/learn/quizzes/${quiz.slug}`} className={styles.card} key={quiz.slug}>
                  <span>QUIZ</span>
                  <h2>{quiz.title}</h2>
                  <p>{quiz.description}</p>
                  <b>Start quiz →</b>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
