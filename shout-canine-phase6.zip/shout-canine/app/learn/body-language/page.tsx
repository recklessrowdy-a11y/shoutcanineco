import Link from "next/link";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

const signals = [
  ["Eyes", "Whale eye, hard staring, gaze shifts, blinking, eye shape"],
  ["Ears", "Forward, neutral, lateral, pinned, rapidly shifting"],
  ["Mouth", "Soft mouth, lip tension, panting, licking, yawning, vocalization"],
  ["Tail", "Height, stiffness, speed, range, whole-body movement"],
  ["Hackles", "Piloerection can accompany arousal and should be read in context"],
  ["Weight", "Forward, neutral, leaning away, crouched, shifting"],
  ["Movement", "Loose, stiff, curved, direct, freezing, pacing, displacement"],
  ["Distance", "Approaching, avoiding, escaping, hiding, blocking, disengaging"]
];

export default function BodyLanguagePage() {
  return (
    <>
      <Header />
      <main id="main-content">
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">Canine Body Language</p>
            <h1>Learn to Read the Entire Dog</h1>
            <p>
              One behavior rarely tells the entire story. A wagging tail does not automatically mean
              a happy dog. A growl does not automatically mean an aggressive dog. A yawn does not
              automatically mean a tired dog.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.notice}>
              <strong>Context first.</strong>
              <p>
                Consider the whole body, the environment, the dog's history, and what happened immediately
                before the behavior. This content is educational and is not a behavioral diagnosis.
              </p>
            </div>

            <div className={styles.grid}>
              {signals.map(([title, copy]) => (
                <article key={title}>
                  <span>{title}</span>
                  <p>{copy}</p>
                </article>
              ))}
            </div>

            <div className="buttonRow">
              <Link href="/learn/body-language/explorer" className="button">Open Interactive Explorer</Link>
              <Link href="/learn/body-language/what-is-my-dog-telling-me" className="buttonGhost">What Is My Dog Telling Me?</Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
