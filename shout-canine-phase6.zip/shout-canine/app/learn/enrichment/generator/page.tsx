import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { EnrichmentGenerator } from "@/components/interactive/EnrichmentGenerator";

export const metadata = {
  title: "Dog Enrichment Generator",
  description:
    "Build a practical dog enrichment plan based on age, energy, motivation, mobility, environment, and time available."
};

export default function EnrichmentGeneratorPage() {
  return (
    <>
      <Header />
      <main id="main-content">
        <section className="section">
          <div className="container">
            <p className="eyebrow">Interactive enrichment</p>
            <h1 className="sectionTitle">Today's Enrichment Plan</h1>
            <p className="sectionLead">
              Enrichment is more than exercise. Generate a practical mix of sniffing,
              problem-solving, movement, and calming activity around the dog in front of you.
            </p>
            <div style={{ marginTop: 42 }}>
              <EnrichmentGenerator />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
