import type { Metadata } from "next";
import { Analytics } from "@/components/analytics/Analytics";
import { WebVitals } from "@/components/analytics/WebVitals";
import { JsonLd } from "@/components/seo/JsonLd";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://shoutcanine.example";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Shout Canine Co | Dog-Inspired Goods & Canine Education",
    template: "%s | Shout Canine Co"
  },
  description:
    "Dog-inspired goods, breed-focused collections, practical canine education, and resources for people who want to understand dogs as much as they love them.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "Shout Canine Co",
    description: "Understand the dog. Respect the dog. Celebrate the dog.",
    type: "website",
    url: siteUrl,
    siteName: "Shout Canine Co"
  },
  robots: {
    index: true,
    follow: true
  }
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  const siteStructuredData = [
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "Shout Canine Co",
      url: siteUrl
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: "Shout Canine Co",
      url: siteUrl,
      potentialAction: {
        "@type": "SearchAction",
        target: `${siteUrl}/search?q={search_term_string}`,
        "query-input": "required name=search_term_string"
      }
    }
  ];

  return (
    <html lang="en">
      <body>
        <JsonLd data={siteStructuredData} />
        <a className="skipLink" href="#main-content">Skip to main content</a>
        {children}
        <WebVitals />
        <Analytics />
      </body>
    </html>
  );
}
