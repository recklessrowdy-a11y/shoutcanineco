import Link from "next/link";

export default function NotFound() {
  return (
    <main className="statusPage">
      <div>
        <p className="eyebrow">404</p>
        <h1>That trail went cold.</h1>
        <p>The page may have moved, or the link may no longer exist.</p>
        <div className="buttonRow">
          <Link className="button" href="/">Return home</Link>
          <Link className="buttonGhost" href="/search">Search the site</Link>
        </div>
      </div>
    </main>
  );
}
