import Link from "next/link";
import { breeds } from "@/lib/breeds";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

export const metadata = {
  title: "Dog Breed Library",
  description:
    "Explore breed traits, communication tendencies, enrichment ideas, handling considerations, and breed-inspired products."
};

export default function BreedsPage() {
  return (
    <>
      <Header />
      <main id="main-content">
        <section className="section">
          <div className="container">
            <p className="eyebrow">Breed Library</p>
            <h1 className="sectionTitle">Know the breed. Notice the individual.</h1>
            <p className="sectionLead">
              Breed history can influence tendencies, but it never replaces observing the dog in front of you.
              Use these guides as context—not a personality guarantee.
            </p>

            <div className={styles.grid}>
              {breeds.map((breed) => (
                <Link className={styles.card} href={`/breeds/${breed.slug}`} key={breed.slug}>
                  <span>{breed.group}</span>
                  <h2>{breed.name}</h2>
                  <p>{breed.intro}</p>
                  <b>Explore breed hub →</b>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
