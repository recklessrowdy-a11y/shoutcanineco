import { NextRequest, NextResponse } from "next/server";

function validEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

export async function POST(request: NextRequest) {
  try {
    const { email, source = "website" } = await request.json();
    const normalized = String(email || "").trim().toLowerCase();

    if (!validEmail(normalized)) {
      return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
    }

    const webhook = process.env.NEWSLETTER_WEBHOOK_URL;
    if (!webhook) {
      return NextResponse.json(
        { error: "Newsletter provider is not configured yet." },
        { status: 503 }
      );
    }

    const response = await fetch(webhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(process.env.NEWSLETTER_WEBHOOK_SECRET
          ? { Authorization: `Bearer ${process.env.NEWSLETTER_WEBHOOK_SECRET}` }
          : {})
      },
      body: JSON.stringify({ email: normalized, source }),
      cache: "no-store",
      signal: AbortSignal.timeout(6000)
    });

    if (!response.ok) {
      return NextResponse.json({ error: "Subscription provider rejected the request." }, { status: 502 });
    }

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Unable to process subscription." }, { status: 400 });
  }
}
