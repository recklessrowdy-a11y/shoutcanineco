import { NextRequest, NextResponse } from "next/server";
import {
  addCartLines,
  createCart,
  getCart,
  isShopifyConfigured,
  removeCartLine,
  updateCartLine
} from "@/lib/shopify";

const CART_COOKIE = "shout_cart";

function buyerIp(request: NextRequest) {
  return (
    request.headers.get("x-vercel-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    null
  );
}

function safeQuantity(value: unknown) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed > 50) {
    throw new Error("Quantity must be an integer between 0 and 50.");
  }
  return parsed;
}

function cartResponse(cart: unknown, status = 200) {
  return NextResponse.json({ cart }, { status });
}

function errorResponse(error: unknown, status = 400) {
  const message = error instanceof Error ? error.message : "Cart request failed.";
  return NextResponse.json({ error: message }, { status });
}

export async function GET(request: NextRequest) {
  if (!isShopifyConfigured()) {
    return NextResponse.json({ cart: null, configured: false });
  }

  const cartId = request.cookies.get(CART_COOKIE)?.value;
  if (!cartId) return NextResponse.json({ cart: null, configured: true });

  try {
    const cart = await getCart(cartId, buyerIp(request));
    return NextResponse.json({ cart, configured: true });
  } catch {
    const response = NextResponse.json({ cart: null, configured: true });
    response.cookies.delete(CART_COOKIE);
    return response;
  }
}

export async function POST(request: NextRequest) {
  if (!isShopifyConfigured()) {
    return errorResponse(new Error("Live commerce is not configured."), 503);
  }

  try {
    const body = await request.json();
    const merchandiseId = String(body.merchandiseId || "");
    const quantity = safeQuantity(body.quantity ?? 1);

    if (!merchandiseId.startsWith("gid://shopify/ProductVariant/")) {
      return errorResponse(new Error("A valid Shopify ProductVariant ID is required."));
    }
    if (quantity < 1) {
      return errorResponse(new Error("Quantity must be at least 1 when adding an item."));
    }

    const existingCartId = request.cookies.get(CART_COOKIE)?.value;
    const cart = existingCartId
      ? await addCartLines(existingCartId, merchandiseId, quantity, buyerIp(request))
      : await createCart(merchandiseId, quantity, buyerIp(request));

    const response = cartResponse(cart);
    response.cookies.set(CART_COOKIE, cart.id, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 14
    });
    return response;
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: NextRequest) {
  if (!isShopifyConfigured()) return errorResponse(new Error("Live commerce is not configured."), 503);

  const cartId = request.cookies.get(CART_COOKIE)?.value;
  if (!cartId) return errorResponse(new Error("No active cart."), 404);

  try {
    const body = await request.json();
    const lineId = String(body.lineId || "");
    const quantity = safeQuantity(body.quantity);

    if (!lineId.startsWith("gid://shopify/CartLine/")) {
      return errorResponse(new Error("A valid Shopify cart line ID is required."));
    }

    const cart = quantity === 0
      ? await removeCartLine(cartId, lineId, buyerIp(request))
      : await updateCartLine(cartId, lineId, quantity, buyerIp(request));

    return cartResponse(cart);
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(request: NextRequest) {
  if (!isShopifyConfigured()) return errorResponse(new Error("Live commerce is not configured."), 503);

  const cartId = request.cookies.get(CART_COOKIE)?.value;
  if (!cartId) return errorResponse(new Error("No active cart."), 404);

  try {
    const body = await request.json();
    const lineId = String(body.lineId || "");
    if (!lineId.startsWith("gid://shopify/CartLine/")) {
      return errorResponse(new Error("A valid Shopify cart line ID is required."));
    }

    const cart = await removeCartLine(cartId, lineId, buyerIp(request));
    return cartResponse(cart);
  } catch (error) {
    return errorResponse(error);
  }
}
