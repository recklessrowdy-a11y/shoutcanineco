import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Shout Canine Co",
    short_name: "Shout Canine",
    description: "Dog-inspired goods, canine education, breed resources, and professional tools.",
    start_url: "/",
    display: "standalone",
    background_color: "#f3efe7",
    theme_color: "#171513"
  };
}
