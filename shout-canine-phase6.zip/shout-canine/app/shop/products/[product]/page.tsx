import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { AddToCart } from "@/components/commerce/AddToCart";
import { JsonLd } from "@/components/seo/JsonLd";
import { getProduct, products } from "@/lib/products";
import { getShopifyProduct, isShopifyConfigured } from "@/lib/shopify";
import styles from "./page.module.css";

export function generateStaticParams() {
  return products.map((product) => ({ product: product.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ product: string }> }) {
  const { product: slug } = await params;
  const seed = getProduct(slug);
  const live = isShopifyConfigured() ? await getShopifyProduct(slug).catch(() => null) : null;
  const title = live?.title || seed?.name;
  const description = live?.description || seed?.description;
  return title ? { title, description } : {};
}

export default async function ProductPage({ params }: { params: Promise<{ product: string }> }) {
  const { product: slug } = await params;
  const seed = getProduct(slug);
  const live = isShopifyConfigured() ? await getShopifyProduct(slug).catch(() => null) : null;

  if (!seed && !live) notFound();

  const title = live?.title || seed!.name;
  const description = live?.description || seed!.description;
  const variant = live?.variants.nodes.find((item) => item.availableForSale) || live?.variants.nodes[0] || null;
  const price = variant ? Number(variant.price.amount) : seed?.price ?? 0;
  const currency = variant?.price.currencyCode || "USD";
  const productUrl = `${process.env.NEXT_PUBLIC_SITE_URL || "https://shoutcanine.example"}/shop/products/${slug}`;

  const structuredData = live && variant ? {
    "@context": "https://schema.org",
    "@type": "Product",
    name: title,
    description,
    url: productUrl,
    image: live.featuredImage?.url ? [live.featuredImage.url] : undefined,
    offers: {
      "@type": "Offer",
      priceCurrency: currency,
      price: variant.price.amount,
      availability: variant.availableForSale
        ? "https://schema.org/InStock"
        : "https://schema.org/OutOfStock",
      url: productUrl
    }
  } : null;

  return (
    <>
      {structuredData && <JsonLd data={structuredData} />}
      <Header />
      <main id="main-content">
        <section className="section">
          <div className={`container ${styles.layout}`}>
            <div className={styles.art}>
              <span>{seed?.category || "Shout Canine Co"}</span>
              <strong>{title}</strong>
            </div>
            <div className={styles.copy}>
              <p className="eyebrow">{seed?.collection || "Shop"}</p>
              <h1>{title}</h1>
              <p className={styles.price}>
                {new Intl.NumberFormat("en-US", { style: "currency", currency }).format(price)}
              </p>
              <p>{description}</p>

              {live && variant ? (
                <>
                  <div className={styles.notice}>
                    <strong>Live Shopify product</strong>
                    <p>
                      {variant.availableForSale
                        ? `Selected variant: ${variant.title}. Checkout is handled by Shopify.`
                        : "This variant is currently unavailable."}
                    </p>
                  </div>
                  <AddToCart merchandiseId={variant.id} available={variant.availableForSale} />
                </>
              ) : (
                <div className={styles.notice}>
                  <strong>Catalog preview</strong>
                  <p>
                    This product is still using local seed content. Connect Shopify and create a product
                    with the matching handle <code>{slug}</code> to enable live variants and checkout.
                  </p>
                </div>
              )}

              <div className={styles.links}>
                {seed?.breedSlug && <Link href={`/breeds/${seed.breedSlug}`}>Learn about {seed.breed} →</Link>}
                {seed?.tags.includes("body language") && <Link href="/learn/body-language">Explore body language →</Link>}
                {seed?.tags.includes("enrichment") && <Link href="/learn/enrichment">Explore enrichment →</Link>}
                {seed?.tags.includes("professional") && <Link href="/professional">Professional resources →</Link>}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
