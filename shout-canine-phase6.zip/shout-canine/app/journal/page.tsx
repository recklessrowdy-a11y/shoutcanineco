import Link from "next/link";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { journalPosts } from "@/lib/journal";
import styles from "./page.module.css";

export const metadata = {
  title: "Journal",
  description: "Canine behavior, enrichment, breed, professional, and dog-culture articles from Shout Canine Co."
};

export default function JournalPage() {
  return (
    <>
      <Header />
      <main id="main-content">
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">Journal</p>
            <h1>Dog knowledge worth keeping.</h1>
            <p>Editorial articles designed to connect education, tools, breed resources, and the wider Shout ecosystem.</p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.grid}>
              {journalPosts.map((post) => (
                <Link href={`/journal/${post.slug}`} key={post.slug}>
                  <span>{post.category} · {post.readTime}</span>
                  <h2>{post.title}</h2>
                  <p>{post.dek}</p>
                  <b>Read article →</b>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
