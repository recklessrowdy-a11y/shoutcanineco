export type DogProfile = {
  name: string;
  breed: string;
  age: string;
  energy: "low" | "medium" | "high";
  activities: string;
  playStyle: string;
  foodMotivation: "low" | "medium" | "high";
  triggers: string;
  goals: string;
};

export function profileRecommendations(profile: DogProfile) {
  const articles = new Set<string>();
  const enrichment = new Set<string>();
  const resources = new Set<string>();

  if (profile.energy === "high") {
    enrichment.add("Scent trails and search games");
    enrichment.add("Structured movement with decompression pauses");
    articles.add("Understanding Arousal");
  } else {
    enrichment.add("Low-pressure sniffing and observation time");
  }

  if (profile.foodMotivation !== "low") {
    enrichment.add("Scatter feeding or food-search games");
  }

  if (profile.playStyle.toLowerCase().includes("chase")) {
    articles.add("Understanding Chase-Oriented Play");
    resources.add("Group Play Observation Sheet");
  }

  if (profile.triggers.trim()) {
    articles.add("Reading Early Stress Signals");
    resources.add("Weekly Behavior Tracker");
  }

  if (profile.breed.toLowerCase().includes("husky")) {
    articles.add("Siberian Husky Breed Guide");
    enrichment.add("Novel route exploration and scent work");
  }

  resources.add("Dog Profile Summary");
  return {
    articles: [...articles],
    enrichment: [...enrichment],
    resources: [...resources]
  };
}
