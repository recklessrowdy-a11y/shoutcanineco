export type PlayScenario = {
  id: string;
  title: string;
  prompt: string;
  observations: string[];
  choices: { key: string; label: string }[];
  best: string;
  explanation: string;
  notices: string[];
};

export const playScenarios: PlayScenario[] = [
  {
    id: "pause-and-return",
    title: "Pause, shake off, return",
    prompt: "Two dogs stop wrestling. One shakes off, both look away briefly, then re-engage with loose movement.",
    observations: ["Loose bodies", "Natural pause", "Both dogs disengage briefly", "Both dogs choose to return"],
    choices: [
      { key: "healthy", label: "Likely healthy play pattern" },
      { key: "conflict", label: "Likely escalating conflict" },
      { key: "unclear", label: "Impossible to notice anything useful" }
    ],
    best: "healthy",
    explanation:
      "Pauses, disengagement, and voluntary re-engagement can support a healthy-play interpretation when movement stays loose and both dogs retain choice.",
    notices: ["Reciprocity", "Consent checks", "Loose movement", "Escape opportunities"]
  },
  {
    id: "persistent-pressure",
    title: "One dog keeps pressing",
    prompt: "One dog repeatedly body-slams and mounts while the other dog turns away, hides behind a person, and does not re-engage.",
    observations: ["Persistent pressure", "Repeated avoidance", "No role reversal", "One dog is seeking distance"],
    choices: [
      { key: "healthy", label: "Likely healthy play pattern" },
      { key: "conflict", label: "Potentially problematic interaction" },
      { key: "unclear", label: "Nothing here matters" }
    ],
    best: "conflict",
    explanation:
      "Repeated pressure combined with avoidance and lack of re-engagement suggests the interaction may not be mutually enjoyable. Handlers should interrupt before pressure escalates.",
    notices: ["Disengagement", "Cornering risk", "Persistent mounting", "Lack of reciprocity"]
  },
  {
    id: "chase-role-reversal",
    title: "Chase with role reversal",
    prompt: "Two dogs chase in wide arcs. After several seconds, the lead dog slows, turns, and begins chasing the other dog.",
    observations: ["Curved movement", "Role reversal", "Flexible speed", "No dog appears trapped"],
    choices: [
      { key: "healthy", label: "Likely healthy play pattern" },
      { key: "conflict", label: "Likely dangerous by definition" },
      { key: "unclear", label: "Chase can never be evaluated" }
    ],
    best: "healthy",
    explanation:
      "Role reversal and flexible movement can support a playful interpretation when neither dog is being persistently pressured and both can disengage.",
    notices: ["Role reversal", "Curved approaches", "Flexible movement", "Choice"]
  }
];
