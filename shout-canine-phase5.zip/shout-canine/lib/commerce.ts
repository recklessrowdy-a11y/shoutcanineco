/**
 * Commerce boundary for Phase 5.
 *
 * UI components consume normalized local Product data from lib/products.ts.
 * A live Shopify integration should replace this boundary with Storefront API
 * queries while preserving the normalized shape used by the UI.
 *
 * Expected environment variables for a future live adapter:
 * SHOPIFY_STORE_DOMAIN
 * SHOPIFY_STOREFRONT_ACCESS_TOKEN
 *
 * Checkout is intentionally not faked in this seed implementation.
 */
export type CommerceStatus = {
  provider: "seed" | "shopify";
  checkoutEnabled: boolean;
};

export const commerceStatus: CommerceStatus = {
  provider: "seed",
  checkoutEnabled: false
};
