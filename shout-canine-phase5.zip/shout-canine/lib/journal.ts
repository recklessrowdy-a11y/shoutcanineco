export type JournalPost = {
  slug: string;
  title: string;
  category: string;
  dek: string;
  readTime: string;
  sections: { heading: string; body: string }[];
  links: { label: string; href: string }[];
};

export const journalPosts: JournalPost[] = [
  {
    slug: "why-context-changes-canine-body-language",
    title: "Why Context Changes Canine Body Language",
    category: "Behavior",
    dek: "The same visible behavior can mean different things depending on the rest of the dog, the environment, and what happened immediately before it.",
    readTime: "5 min read",
    sections: [
      {
        heading: "Signals are information, not verdicts",
        body: "A yawn, tail wag, growl, gaze shift, or posture change should not be interpreted in isolation. Useful observation combines multiple signals and asks what changed in the environment."
      },
      {
        heading: "Look for patterns",
        body: "Repeated combinations are often more useful than single moments. Notice what precedes the behavior, how the dog changes distance, and what helps the dog recover."
      }
    ],
    links: [
      { label: "Body Language Center", href: "/learn/body-language" },
      { label: "What Is My Dog Telling Me?", href: "/learn/body-language/what-is-my-dog-telling-me" }
    ]
  },
  {
    slug: "enrichment-does-not-have-to-be-complicated",
    title: "Enrichment Does Not Have to Be Complicated",
    category: "Enrichment",
    dek: "Useful enrichment can be simple, repeatable, adjustable, and based on what the individual dog actually enjoys.",
    readTime: "4 min read",
    sections: [
      {
        heading: "Start with function",
        body: "Instead of chasing novelty for its own sake, consider whether an activity supports sniffing, searching, chewing, movement, learning, social interaction, or decompression."
      },
      {
        heading: "Adjust difficulty",
        body: "Enrichment should be challenging enough to engage the dog without repeatedly creating frustration. Make tasks easier when needed and build complexity gradually."
      }
    ],
    links: [
      { label: "Enrichment Center", href: "/learn/enrichment" },
      { label: "Build an Enrichment Plan", href: "/learn/enrichment/generator" }
    ]
  },
  {
    slug: "documenting-behavior-without-labels",
    title: "Documenting Behavior Without Labels",
    category: "Professional",
    dek: "Operational notes become more useful when teams record observable behavior, antecedents, responses, and recovery instead of relying only on personality labels.",
    readTime: "6 min read",
    sections: [
      {
        heading: "Write what happened",
        body: "Record posture, movement, vocalization, distance changes, environmental events, handler responses, and recovery time. This creates information that can be compared across shifts."
      },
      {
        heading: "Keep interpretation separate",
        body: "Teams can discuss possible functions and emotional context after documenting observable events. Separating observation from interpretation improves clarity."
      }
    ],
    links: [
      { label: "Behavior Log Builder", href: "/professional/behavior-log" },
      { label: "Professional Center", href: "/professional" }
    ]
  }
];

export function getJournalPost(slug: string) {
  return journalPosts.find((post) => post.slug === slug);
}
