export type QuizQuestion = {
  prompt: string;
  options: string[];
  correctIndex: number;
  explanation: string;
};

export type Quiz = {
  slug: string;
  title: string;
  description: string;
  questions: QuizQuestion[];
};

export const quizzes: Quiz[] = [
  {
    slug: "stress-signals",
    title: "Can You Read These Stress Signals?",
    description: "A short quiz about noticing early canine stress and uncertainty signals.",
    questions: [
      {
        prompt: "A dog suddenly closes its mouth, turns its head away, and becomes still. What matters most?",
        options: [
          "The closed mouth proves aggression",
          "Read the entire body and immediate context",
          "Ignore it unless the dog growls",
          "A still dog is always relaxed"
        ],
        correctIndex: 1,
        explanation:
          "A single signal rarely tells the whole story. Sudden stillness and facial tension deserve attention alongside posture, distance, environment, and recent events."
      },
      {
        prompt: "Visible whites of the eyes are sometimes called:",
        options: ["Play face", "Whale eye", "Hackles", "Splooting"],
        correctIndex: 1,
        explanation:
          "Whale eye describes visible sclera as the dog turns the head while continuing to monitor something. It must still be interpreted in context."
      },
      {
        prompt: "Which combination most strongly deserves a closer look?",
        options: [
          "Loose movement and broad curves",
          "Stiff body, forward weight, hard stare",
          "Sniffing and turning away",
          "Soft body and role reversal"
        ],
        correctIndex: 1,
        explanation:
          "Stiffness, forward weight, and hard visual focus can accompany increased arousal and should prompt careful management."
      }
    ]
  },
  {
    slug: "enrichment-types",
    title: "What Type of Enrichment Is This?",
    description: "Match enrichment activities to the type of need they may support.",
    questions: [
      {
        prompt: "Scatter feeding primarily adds which element?",
        options: ["Sensory/search opportunity", "Forced exercise", "Guarding practice", "Punishment"],
        correctIndex: 0,
        explanation:
          "Scatter feeding can encourage sniffing and searching, giving the dog a species-typical sensory activity."
      },
      {
        prompt: "A novel sniffing walk most directly supports:",
        options: ["Only cardiovascular fitness", "Sensory exploration", "Obedience compliance", "Resource restriction"],
        correctIndex: 1,
        explanation:
          "Novel routes can offer scent exploration and environmental information beyond simple physical exercise."
      }
    ]
  }
];

export function getQuiz(slug: string) {
  return quizzes.find((quiz) => quiz.slug === slug);
}
