export type Product = {
  slug: string;
  name: string;
  collection: string;
  collectionSlug: string;
  breed?: string;
  breedSlug?: string;
  category: string;
  price: number;
  description: string;
  tags: string[];
};

export const products: Product[] = [
  {
    slug: "siberian-husky-field-notes-tee",
    name: "Siberian Husky Field Notes Tee",
    collection: "Breed Collection",
    collectionSlug: "breed-collection",
    breed: "Siberian Husky",
    breedSlug: "siberian-husky",
    category: "Apparel",
    price: 34,
    description: "A breed-inspired editorial tee concept built for the Shout Canine Co catalog architecture.",
    tags: ["husky", "working dog", "apparel", "breed"]
  },
  {
    slug: "doberman-observation-club-crew",
    name: "Doberman Observation Club Crew",
    collection: "Breed Collection",
    collectionSlug: "breed-collection",
    breed: "Doberman Pinscher",
    breedSlug: "doberman-pinscher",
    category: "Apparel",
    price: 58,
    description: "A Doberman-focused crewneck concept connected to breed education and working-dog content.",
    tags: ["doberman", "working dog", "apparel", "breed"]
  },
  {
    slug: "read-the-whole-dog-poster",
    name: "Read the Whole Dog Poster",
    collection: "Education Collection",
    collectionSlug: "education-collection",
    category: "Print",
    price: 24,
    description: "An educational poster concept reinforcing whole-dog observation and contextual interpretation.",
    tags: ["body language", "education", "poster", "communication"]
  },
  {
    slug: "enrichment-field-guide",
    name: "Enrichment Field Guide",
    collection: "Education Collection",
    collectionSlug: "education-collection",
    category: "Guide",
    price: 18,
    description: "A printable-style field guide concept for planning sensory, cognitive, physical, and calming enrichment.",
    tags: ["enrichment", "guide", "education"]
  },
  {
    slug: "professional-behavior-log-pad",
    name: "Professional Behavior Log Pad",
    collection: "Professional Collection",
    collectionSlug: "professional-collection",
    category: "Professional",
    price: 22,
    description: "A professional documentation concept aligned with the digital behavior-log workflow.",
    tags: ["professional", "behavior log", "daycare", "trainer"]
  },
  {
    slug: "group-play-observation-cards",
    name: "Group Play Observation Cards",
    collection: "Professional Collection",
    collectionSlug: "professional-collection",
    category: "Professional",
    price: 28,
    description: "Reference-card concepts for noticing reciprocity, pauses, pressure, disengagement, and arousal.",
    tags: ["professional", "dog play", "group care", "behavior"]
  }
];

export const collections = [
  {
    slug: "breed-collection",
    name: "Breed Collection",
    description: "Breed-inspired goods linked directly to the breed library."
  },
  {
    slug: "education-collection",
    name: "Education Collection",
    description: "Goods and resources built around canine communication, enrichment, and learning."
  },
  {
    slug: "professional-collection",
    name: "Professional Collection",
    description: "Tools and merchandise concepts for trainers, daycare teams, groomers, and other dog professionals."
  }
];

export function getProduct(slug: string) {
  return products.find((product) => product.slug === slug);
}

export function getCollection(slug: string) {
  return collections.find((collection) => collection.slug === slug);
}

export function productsForCollection(slug: string) {
  return products.filter((product) => product.collectionSlug === slug);
}
