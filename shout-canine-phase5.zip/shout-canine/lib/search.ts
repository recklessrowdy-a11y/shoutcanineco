import { breeds } from "./breeds";
import { educationCategories } from "./education";
import { journalPosts } from "./journal";
import { products } from "./products";
import { quizzes } from "./quizzes";

export type SearchItem = {
  title: string;
  type: string;
  href: string;
  description: string;
  terms: string;
};

export const searchIndex: SearchItem[] = [
  ...breeds.map((breed) => ({
    title: breed.name,
    type: "Breed",
    href: `/breeds/${breed.slug}`,
    description: breed.intro,
    terms: [breed.name, breed.group, ...breed.traits].join(" ")
  })),
  ...educationCategories.map((category) => ({
    title: category.title,
    type: "Education",
    href: `/learn/${category.slug}`,
    description: category.description,
    terms: `${category.title} ${category.description}`
  })),
  ...products.map((product) => ({
    title: product.name,
    type: "Product",
    href: `/shop/products/${product.slug}`,
    description: product.description,
    terms: [product.name, product.collection, product.category, ...product.tags].join(" ")
  })),
  ...journalPosts.map((post) => ({
    title: post.title,
    type: "Journal",
    href: `/journal/${post.slug}`,
    description: post.dek,
    terms: `${post.title} ${post.category} ${post.dek}`
  })),
  ...quizzes.map((quiz) => ({
    title: quiz.title,
    type: "Quiz",
    href: `/learn/quizzes/${quiz.slug}`,
    description: quiz.description,
    terms: `${quiz.title} ${quiz.description}`
  })),
  {
    title: "What Is My Dog Telling Me?",
    type: "Tool",
    href: "/learn/body-language/what-is-my-dog-telling-me",
    description: "Guided canine body-language observation tool.",
    terms: "body language dog telling me signals ears mouth tail posture context"
  },
  {
    title: "Dog Enrichment Generator",
    type: "Tool",
    href: "/learn/enrichment/generator",
    description: "Generate a practical enrichment plan.",
    terms: "enrichment generator activity dog plan sniffing"
  },
  {
    title: "Dog Profile Builder",
    type: "Tool",
    href: "/tools/dog-profile",
    description: "Organize education and enrichment recommendations around an individual dog.",
    terms: "dog profile breed energy play style triggers goals"
  },
  {
    title: "Behavior Log Builder",
    type: "Professional Tool",
    href: "/professional/behavior-log",
    description: "Document observable behavior, triggers, responses, and recovery.",
    terms: "professional behavior log daycare trainer record"
  }
];

export function searchSite(query: string) {
  const terms = query.toLowerCase().trim().split(/\s+/).filter(Boolean);
  if (!terms.length) return searchIndex;

  return searchIndex
    .map((item) => {
      const haystack = `${item.title} ${item.type} ${item.description} ${item.terms}`.toLowerCase();
      const score = terms.reduce((total, term) => total + (haystack.includes(term) ? 1 : 0), 0);
      return { item, score };
    })
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score || a.item.title.localeCompare(b.item.title))
    .map(({ item }) => item);
}
