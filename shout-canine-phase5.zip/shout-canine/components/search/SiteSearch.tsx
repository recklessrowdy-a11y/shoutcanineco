"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { searchSite } from "@/lib/search";
import styles from "./SiteSearch.module.css";

export function SiteSearch() {
  const [query, setQuery] = useState("");
  const results = useMemo(() => searchSite(query), [query]);

  return (
    <div className={styles.search}>
      <label>
        <span>Search Shout Canine Co</span>
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Try “body language”, “husky”, “enrichment”…"
          autoFocus
        />
      </label>

      <div className={styles.meta}>
        <span>{results.length} results</span>
        {query && <span>for “{query}”</span>}
      </div>

      <div className={styles.results}>
        {results.map((item) => (
          <Link href={item.href} key={`${item.type}-${item.href}`}>
            <span>{item.type}</span>
            <h2>{item.title}</h2>
            <p>{item.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
