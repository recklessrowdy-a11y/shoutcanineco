import Link from "next/link";
import type { Product } from "@/lib/products";
import styles from "./ProductCard.module.css";

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className={styles.card}>
      <Link href={`/shop/products/${product.slug}`} className={styles.art} aria-label={product.name}>
        <span>{product.category}</span>
        <strong>{product.name}</strong>
      </Link>
      <div className={styles.copy}>
        <p>{product.collection}</p>
        <h3><Link href={`/shop/products/${product.slug}`}>{product.name}</Link></h3>
        <div>
          <span>${product.price.toFixed(2)}</span>
          <Link href={`/shop/products/${product.slug}`}>View →</Link>
        </div>
      </div>
    </article>
  );
}
