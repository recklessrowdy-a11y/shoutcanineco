"use client";

import { FormEvent, useState } from "react";
import { DogProfile, profileRecommendations } from "@/lib/profile";
import styles from "./DogProfileBuilder.module.css";

const initial: DogProfile = {
  name: "",
  breed: "",
  age: "",
  energy: "medium",
  activities: "",
  playStyle: "",
  foodMotivation: "medium",
  triggers: "",
  goals: ""
};

export function DogProfileBuilder() {
  const [profile, setProfile] = useState<DogProfile>(initial);
  const [result, setResult] = useState<ReturnType<typeof profileRecommendations> | null>(null);

  function update<K extends keyof DogProfile>(key: K, value: DogProfile[K]) {
    setProfile((current) => ({ ...current, [key]: value }));
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    setResult(profileRecommendations(profile));
  }

  return (
    <div className={styles.layout}>
      <form className={styles.form} onSubmit={submit}>
        <Input label="Dog name" value={profile.name} onChange={(v) => update("name", v)} />
        <Input label="Breed" value={profile.breed} onChange={(v) => update("breed", v)} />
        <Input label="Age" value={profile.age} onChange={(v) => update("age", v)} />

        <label className={styles.field}>
          <span>Energy level</span>
          <select value={profile.energy} onChange={(e) => update("energy", e.target.value as DogProfile["energy"])}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </label>

        <Input label="Favorite activities" value={profile.activities} onChange={(v) => update("activities", v)} />
        <Input label="Play style" value={profile.playStyle} onChange={(v) => update("playStyle", v)} placeholder="e.g. chase, wrestling, parallel exploration" />

        <label className={styles.field}>
          <span>Food motivation</span>
          <select value={profile.foodMotivation} onChange={(e) => update("foodMotivation", e.target.value as DogProfile["foodMotivation"])}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </label>

        <Input label="Common triggers" value={profile.triggers} onChange={(v) => update("triggers", v)} />
        <Input label="Training goals" value={profile.goals} onChange={(v) => update("goals", v)} />

        <button className="button" type="submit">Build profile</button>
      </form>

      <section className={styles.output} aria-live="polite">
        {!result ? (
          <div className={styles.empty}>
            <p className="eyebrow">Personalized discovery</p>
            <h2>Build the dog, not a diagnosis.</h2>
            <p>Recommendations will appear here based on the profile information you enter.</p>
          </div>
        ) : (
          <>
            <p className="eyebrow">{profile.name || "Dog"} profile</p>
            <h2>{profile.breed || "Individual dog"}</h2>
            <p className={styles.note}>
              These recommendations organize site content and enrichment ideas. They do not diagnose behavior or guarantee suitability.
            </p>

            <Recommendation title="Education" items={result.articles} />
            <Recommendation title="Enrichment" items={result.enrichment} />
            <Recommendation title="Printable resources" items={result.resources} />
          </>
        )}
      </section>
    </div>
  );
}

function Input({
  label, value, onChange, placeholder
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label className={styles.field}>
      <span>{label}</span>
      <input value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

function Recommendation({ title, items }: { title: string; items: string[] }) {
  return (
    <div className={styles.recommendation}>
      <strong>{title}</strong>
      <ul>{items.map((item) => <li key={item}>{item}</li>)}</ul>
    </div>
  );
}
