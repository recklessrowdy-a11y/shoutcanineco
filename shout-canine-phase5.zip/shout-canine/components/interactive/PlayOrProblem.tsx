"use client";

import { useState } from "react";
import { playScenarios } from "@/lib/play";
import styles from "./PlayOrProblem.module.css";

export function PlayOrProblem() {
  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState<string | null>(null);
  const scenario = playScenarios[index];

  function next() {
    setAnswer(null);
    setIndex((current) => (current + 1) % playScenarios.length);
  }

  return (
    <div className={styles.shell}>
      <div className={styles.topbar}>
        <span>Scenario {index + 1} / {playScenarios.length}</span>
        <strong>{scenario.title}</strong>
      </div>

      <div className={styles.scene}>
        <div className={styles.visual} aria-hidden="true">
          <div className={styles.dogA}>A</div>
          <div className={styles.dogB}>B</div>
        </div>

        <div className={styles.copy}>
          <p className="eyebrow">What would you notice first?</p>
          <h2>{scenario.prompt}</h2>

          <div className={styles.observations}>
            {scenario.observations.map((item) => <span key={item}>{item}</span>)}
          </div>

          <div className={styles.choices}>
            {scenario.choices.map((choice) => (
              <button
                key={choice.key}
                aria-pressed={answer === choice.key}
                onClick={() => setAnswer(choice.key)}
              >
                {choice.label}
              </button>
            ))}
          </div>

          {answer && (
            <div className={styles.feedback} aria-live="polite">
              <strong>{answer === scenario.best ? "Good read." : "Look at the interaction again."}</strong>
              <p>{scenario.explanation}</p>
              <div>
                {scenario.notices.map((item) => <span key={item}>{item}</span>)}
              </div>
            </div>
          )}

          <button type="button" className="button" onClick={next}>Next scenario</button>
        </div>
      </div>
    </div>
  );
}
