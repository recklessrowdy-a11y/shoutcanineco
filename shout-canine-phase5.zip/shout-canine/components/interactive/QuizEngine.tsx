"use client";

import { useMemo, useState } from "react";
import type { Quiz } from "@/lib/quizzes";
import styles from "./QuizEngine.module.css";

export function QuizEngine({ quiz }: { quiz: Quiz }) {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);

  const score = useMemo(() => {
    return quiz.questions.reduce(
      (total, q, index) => total + (answers[index] === q.correctIndex ? 1 : 0),
      0
    );
  }, [answers, quiz.questions]);

  const complete = Object.keys(answers).length === quiz.questions.length;

  function reset() {
    setAnswers({});
    setSubmitted(false);
  }

  return (
    <div className={styles.shell}>
      {quiz.questions.map((question, index) => (
        <fieldset key={question.prompt} className={styles.question}>
          <legend>
            <span>{String(index + 1).padStart(2, "0")}</span>
            {question.prompt}
          </legend>

          <div className={styles.options}>
            {question.options.map((option, optionIndex) => {
              const selected = answers[index] === optionIndex;
              const correct = submitted && optionIndex === question.correctIndex;
              const wrongSelected = submitted && selected && optionIndex !== question.correctIndex;
              return (
                <button
                  type="button"
                  key={option}
                  aria-pressed={selected}
                  className={correct ? styles.correct : wrongSelected ? styles.wrong : ""}
                  onClick={() => {
                    if (!submitted) setAnswers((current) => ({ ...current, [index]: optionIndex }));
                  }}
                >
                  {option}
                </button>
              );
            })}
          </div>

          {submitted && (
            <p className={styles.explanation}>{question.explanation}</p>
          )}
        </fieldset>
      ))}

      <div className={styles.actions}>
        {!submitted ? (
          <button type="button" className="button" disabled={!complete} onClick={() => setSubmitted(true)}>
            Score my quiz
          </button>
        ) : (
          <>
            <div className={styles.score}>
              <span>You scored</span>
              <strong>{score}/{quiz.questions.length}</strong>
              <b>{score === quiz.questions.length ? "Canine Communication Detective" : "Keep observing the whole dog"}</b>
            </div>
            <button type="button" className="buttonGhost" onClick={reset}>Try again</button>
          </>
        )}
      </div>
    </div>
  );
}
