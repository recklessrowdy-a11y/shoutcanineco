"use client";

import { FormEvent, useState } from "react";
import styles from "./ProfessionalTools.module.css";

type Log = {
  dog: string;
  date: string;
  environment: string;
  trigger: string;
  behavior: string;
  intensity: string;
  response: string;
  recovery: string;
  notes: string;
};

const initial: Log = {
  dog: "",
  date: "",
  environment: "",
  trigger: "",
  behavior: "",
  intensity: "3",
  response: "",
  recovery: "",
  notes: ""
};

export function BehaviorLogBuilder() {
  const [form, setForm] = useState(initial);
  const [record, setRecord] = useState<Log | null>(null);

  function update(key: keyof Log, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    setRecord(form);
  }

  return (
    <div className={styles.layout}>
      <form className={styles.form} onSubmit={submit}>
        {[
          ["dog", "Dog name"],
          ["date", "Date"],
          ["environment", "Environment"],
          ["trigger", "Trigger / antecedent"],
          ["behavior", "Observed behavior"],
          ["response", "Handler response"],
          ["recovery", "Recovery time"],
          ["notes", "Notes"]
        ].map(([key, label]) => (
          <label key={key}>
            <span>{label}</span>
            <input
              type={key === "date" ? "date" : "text"}
              value={form[key as keyof Log]}
              onChange={(e) => update(key as keyof Log, e.target.value)}
            />
          </label>
        ))}

        <label>
          <span>Intensity: {form.intensity}/5</span>
          <input type="range" min="1" max="5" value={form.intensity} onChange={(e) => update("intensity", e.target.value)} />
        </label>

        <button className="button" type="submit">Build record</button>
      </form>

      <section className={styles.output}>
        {!record ? (
          <div className={styles.empty}>
            <p className="eyebrow">Behavior record</p>
            <h2>Document what happened.</h2>
            <p>Completed records can be printed for team use or case review.</p>
          </div>
        ) : (
          <>
            <p className="eyebrow">Behavior Log</p>
            <h2>{record.dog || "Dog"}</h2>
            <dl>
              <Row term="Date" value={record.date} />
              <Row term="Environment" value={record.environment} />
              <Row term="Trigger" value={record.trigger} />
              <Row term="Behavior" value={record.behavior} />
              <Row term="Intensity" value={`${record.intensity}/5`} />
              <Row term="Handler response" value={record.response} />
              <Row term="Recovery" value={record.recovery} />
              <Row term="Notes" value={record.notes} />
            </dl>
            <button className="buttonGhost" type="button" onClick={() => window.print()}>Print record</button>
          </>
        )}
      </section>
    </div>
  );
}

function Row({ term, value }: { term: string; value: string }) {
  return (
    <div>
      <dt>{term}</dt>
      <dd>{value || "—"}</dd>
    </div>
  );
}
