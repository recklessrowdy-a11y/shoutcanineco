"use client";

import { FormEvent, useMemo, useState } from "react";
import styles from "./ProfessionalTools.module.css";

type Form = {
  playStyle: string;
  energy: "low" | "medium" | "high";
  size: "small" | "medium" | "large";
  arousal: "low" | "medium" | "high";
  confidence: "low" | "medium" | "high";
  resources: "none" | "mild" | "significant";
  barriers: "none" | "mild" | "significant";
  handling: "easy" | "variable" | "difficult";
};

const initial: Form = {
  playStyle: "parallel",
  energy: "medium",
  size: "medium",
  arousal: "medium",
  confidence: "medium",
  resources: "none",
  barriers: "none",
  handling: "easy"
};

function guidance(form: Form) {
  let management = 0;
  if (form.arousal === "high") management += 2;
  if (form.resources === "significant") management += 3;
  if (form.barriers === "significant") management += 2;
  if (form.handling === "difficult") management += 2;
  if (form.confidence === "low") management += 1;

  if (management >= 6) {
    return {
      level: "High management need",
      body:
        "This profile contains several factors that may increase management complexity. Consider lower-arousal setups, careful resource control, predictable handling, and individualized introductions rather than relying on group placement."
    };
  }
  if (management >= 3) {
    return {
      level: "Moderate management need",
      body:
        "This profile suggests some factors worth actively managing. Match play style and energy thoughtfully, provide easy disengagement, control resources, and reassess as arousal changes."
    };
  }
  return {
    level: "Lower management complexity",
    body:
      "The selected profile contains fewer obvious management flags, but compatibility still depends on the specific dogs, environment, handler skill, health, history, and what happens in real time."
  };
}

export function GroupPlayCompatibility() {
  const [form, setForm] = useState<Form>(initial);
  const [submitted, setSubmitted] = useState(false);
  const result = useMemo(() => guidance(form), [form]);

  function update<K extends keyof Form>(key: K, value: Form[K]) {
    setForm((current) => ({ ...current, [key]: value }));
    setSubmitted(false);
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    setSubmitted(true);
  }

  return (
    <div className={styles.layout}>
      <form className={styles.form} onSubmit={submit}>
        <Select label="Play style" value={form.playStyle} onChange={(v) => update("playStyle", v)} options={[
          ["parallel", "Parallel exploration"], ["chase", "Chase-oriented"], ["wrestling", "Wrestling"], ["contact", "Body-contact"], ["mouth", "Mouth play"]
        ]} />
        <Select label="Energy" value={form.energy} onChange={(v) => update("energy", v as Form["energy"])} options={[["low","Low"],["medium","Medium"],["high","High"]]} />
        <Select label="Size" value={form.size} onChange={(v) => update("size", v as Form["size"])} options={[["small","Small"],["medium","Medium"],["large","Large"]]} />
        <Select label="Arousal" value={form.arousal} onChange={(v) => update("arousal", v as Form["arousal"])} options={[["low","Low"],["medium","Medium"],["high","High"]]} />
        <Select label="Social confidence" value={form.confidence} onChange={(v) => update("confidence", v as Form["confidence"])} options={[["low","Low"],["medium","Medium"],["high","High"]]} />
        <Select label="Resource concerns" value={form.resources} onChange={(v) => update("resources", v as Form["resources"])} options={[["none","None known"],["mild","Mild"],["significant","Significant"]]} />
        <Select label="Barrier behavior" value={form.barriers} onChange={(v) => update("barriers", v as Form["barriers"])} options={[["none","None known"],["mild","Mild"],["significant","Significant"]]} />
        <Select label="Handling tolerance" value={form.handling} onChange={(v) => update("handling", v as Form["handling"])} options={[["easy","Generally easy"],["variable","Variable"],["difficult","Difficult"]]} />
        <button className="button" type="submit">Generate organizational guidance</button>
      </form>

      <section className={styles.output}>
        {!submitted ? (
          <div className={styles.empty}>
            <p className="eyebrow">Group Play Compatibility Worksheet</p>
            <h2>Organize observations. Never guarantee compatibility.</h2>
            <p>This tool is for operational guidance, not prediction.</p>
          </div>
        ) : (
          <>
            <p className="eyebrow">Organizational guidance</p>
            <h2>{result.level}</h2>
            <p>{result.body}</p>
            <div className={styles.notice}>
              <strong>Important</strong>
              <p>
                This worksheet cannot determine whether two dogs are safe together. Compatibility must be assessed through qualified observation, appropriate introductions, environment management, and ongoing reassessment.
              </p>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

function Select({
  label, value, onChange, options
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: [string, string][];
}) {
  return (
    <label>
      <span>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map(([value, label]) => <option value={value} key={value}>{label}</option>)}
      </select>
    </label>
  );
}
