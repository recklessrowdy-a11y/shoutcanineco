# Shout Canine Co — Homepage Foundation

Production-oriented starter built with Next.js App Router + TypeScript.

## Run locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Included
- Responsive sticky header + mega navigation
- Editorial hero
- Choose Your Path segmentation
- Breed discovery grid
- Featured collection system
- Education feature
- Professional resources feature
- Meet Shout section
- Journal cards
- Community section
- Newsletter capture
- Responsive footer
- Reduced-motion accessibility support
- Reusable global design tokens and layout primitives

Replace the abstract art placeholders with licensed/owned Shout photography and product imagery when assets are ready.

## Phase 2 extension
- Breed Library index
- Dynamic breed hub route
- Siberian Husky + Doberman seed data
- Learn hub
- Education category route architecture
- Canine Body Language Center
- Interactive Body Language Explorer shell
- Reusable behavior article template
- Homepage/header links wired into the new architecture

### Key routes
- `/breeds`
- `/breeds/siberian-husky`
- `/breeds/doberman-pinscher`
- `/learn`
- `/learn/body-language`
- `/learn/body-language/explorer`
- `/learn/behavior`
- `/learn/behavior/sample-guide`

## Phase 3 extension
- Guided "What Is My Dog Telling Me?" questionnaire
- Deterministic body-language interpretation scoring
- Observation review + contextual safety disclaimer
- Enrichment Center
- Enrichment Generator with age, energy, motivation, mobility, environment, and time inputs
- Generated warm-up, main activity, calming activity, optional challenge, and safety considerations
- Print-friendly enrichment plan output

### New routes
- `/learn/body-language/what-is-my-dog-telling-me`
- `/learn/enrichment`
- `/learn/enrichment/generator`

## Phase 4 extension
- Play or Problem? interactive dog-play scenarios
- Reusable gamified quiz engine
- Stress Signals and Enrichment Types quizzes
- Dog Profile Builder with deterministic content recommendations
- Professional Center landing page
- Build a Dog Behavior Log tool
- Group Play Compatibility Worksheet with management-guidance logic
- Print-friendly professional behavior records

### New routes
- `/learn/dog-play/play-or-problem`
- `/learn/quizzes`
- `/learn/quizzes/stress-signals`
- `/learn/quizzes/enrichment-types`
- `/tools/dog-profile`
- `/professional`
- `/professional/behavior-log`
- `/professional/group-play-compatibility`

## Phase 5 extension
- Commerce/catalog architecture with normalized product + collection data
- Product cards, shop landing, collection pages, product detail pages
- Shopify-ready commerce boundary (live checkout intentionally not faked)
- Unified client-side search across breeds, education, tools, quizzes, journal, and products
- Journal landing + reusable article route architecture
- Cross-links from products into breed, education, and professional resources
- Sitemap and robots metadata routes
- JSON-LD helper for structured-data expansion
- Site URL environment-variable convention via `NEXT_PUBLIC_SITE_URL`

### New routes
- `/shop`
- `/shop/collections/[collection]`
- `/shop/products/[product]`
- `/journal`
- `/journal/[slug]`
- `/search`

### Live commerce handoff
The project deliberately keeps checkout disabled until a real commerce backend is connected.
A Shopify Storefront API adapter can replace the seed repository in `lib/commerce.ts` / `lib/products.ts`
without changing the presentation architecture.
