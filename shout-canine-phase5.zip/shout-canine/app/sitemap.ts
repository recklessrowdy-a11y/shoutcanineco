import type { MetadataRoute } from "next";
import { breeds } from "@/lib/breeds";
import { journalPosts } from "@/lib/journal";
import { products, collections } from "@/lib/products";
import { quizzes } from "@/lib/quizzes";

const base = process.env.NEXT_PUBLIC_SITE_URL || "https://shoutcanine.example";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    "", "/breeds", "/learn", "/learn/body-language",
    "/learn/body-language/explorer",
    "/learn/body-language/what-is-my-dog-telling-me",
    "/learn/enrichment", "/learn/enrichment/generator",
    "/learn/dog-play/play-or-problem", "/learn/quizzes",
    "/tools/dog-profile", "/professional",
    "/professional/behavior-log", "/professional/group-play-compatibility",
    "/shop", "/journal", "/search"
  ];

  return [
    ...staticRoutes.map((route) => ({ url: `${base}${route}`, changeFrequency: "weekly" as const })),
    ...breeds.map((breed) => ({ url: `${base}/breeds/${breed.slug}`, changeFrequency: "monthly" as const })),
    ...journalPosts.map((post) => ({ url: `${base}/journal/${post.slug}`, changeFrequency: "monthly" as const })),
    ...products.map((product) => ({ url: `${base}/shop/products/${product.slug}`, changeFrequency: "weekly" as const })),
    ...collections.map((collection) => ({ url: `${base}/shop/collections/${collection.slug}`, changeFrequency: "weekly" as const })),
    ...quizzes.map((quiz) => ({ url: `${base}/learn/quizzes/${quiz.slug}`, changeFrequency: "monthly" as const }))
  ];
}
