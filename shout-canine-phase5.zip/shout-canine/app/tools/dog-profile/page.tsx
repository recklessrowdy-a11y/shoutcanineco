import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { DogProfileBuilder } from "@/components/interactive/DogProfileBuilder";

export const metadata = {
  title: "Dog Profile Builder",
  description:
    "Create a simple dog profile and receive educational, enrichment, breed, and printable-resource recommendations."
};

export default function DogProfilePage() {
  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className="container">
            <p className="eyebrow">Dog Profile Builder</p>
            <h1 className="sectionTitle">Tell us about the dog in front of you.</h1>
            <p className="sectionLead">
              Create a simple profile to organize relevant education, enrichment ideas, breed resources,
              and printable trackers without framing recommendations as diagnoses.
            </p>

            <div style={{ marginTop: 40 }}>
              <DogProfileBuilder />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
