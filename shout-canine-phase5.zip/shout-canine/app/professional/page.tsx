import Link from "next/link";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

const tools = [
  ["Build a Dog Behavior Log", "Document trigger, behavior, intensity, handler response, recovery time, and notes.", "/professional/behavior-log"],
  ["Group Play Compatibility Worksheet", "Organize play style, energy, arousal, resource concerns, barriers, and handling tolerance.", "/professional/group-play-compatibility"]
];

export default function ProfessionalPage() {
  return (
    <>
      <Header />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">Professional</p>
            <h1>For People Who Work With Dogs</h1>
            <p>
              Practical tools built around multi-dog care, documentation, owner communication, team consistency, and safer decision-making.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.grid}>
              {tools.map(([title, copy, href]) => (
                <Link href={href} key={title}>
                  <span>TOOL</span>
                  <h2>{title}</h2>
                  <p>{copy}</p>
                  <b>Open tool →</b>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
