import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { getJournalPost, journalPosts } from "@/lib/journal";
import styles from "./page.module.css";

export function generateStaticParams() {
  return journalPosts.map((post) => ({ slug: post.slug }));
}

export default async function JournalPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = getJournalPost(slug);
  if (!post) notFound();

  return (
    <>
      <Header />
      <main>
        <article>
          <header className={styles.hero}>
            <div className="container">
              <p className="eyebrow">{post.category} · {post.readTime}</p>
              <h1>{post.title}</h1>
              <p>{post.dek}</p>
            </div>
          </header>
          <div className={`container ${styles.body}`}>
            <div>
              {post.sections.map((section) => (
                <section key={section.heading}>
                  <h2>{section.heading}</h2>
                  <p>{section.body}</p>
                </section>
              ))}
              <aside>
                <strong>Keep exploring</strong>
                {post.links.map((link) => <Link href={link.href} key={link.href}>{link.label} →</Link>)}
              </aside>
            </div>
          </div>
        </article>
      </main>
      <Footer />
    </>
  );
}
