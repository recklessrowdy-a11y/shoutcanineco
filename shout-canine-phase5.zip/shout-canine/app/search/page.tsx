import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { SiteSearch } from "@/components/search/SiteSearch";

export const metadata = {
  title: "Search",
  description: "Search breeds, education, journal articles, tools, quizzes, and product concepts."
};

export default function SearchPage() {
  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className="container">
            <p className="eyebrow">Unified search</p>
            <h1 className="sectionTitle">Find the next useful thing.</h1>
            <p className="sectionLead">
              Search across breeds, canine education, interactive tools, quizzes, journal articles,
              professional resources, and the product catalog.
            </p>
            <div style={{ marginTop: 38 }}>
              <SiteSearch />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
