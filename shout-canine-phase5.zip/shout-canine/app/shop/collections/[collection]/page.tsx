import { notFound } from "next/navigation";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { ProductCard } from "@/components/commerce/ProductCard";
import { collections, getCollection, productsForCollection } from "@/lib/products";

export function generateStaticParams() {
  return collections.map((collection) => ({ collection: collection.slug }));
}

export default async function CollectionPage({
  params
}: {
  params: Promise<{ collection: string }>
}) {
  const { collection: slug } = await params;
  const collection = getCollection(slug);
  if (!collection) notFound();
  const products = productsForCollection(slug);

  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className="container">
            <p className="eyebrow">Shop collection</p>
            <h1 className="sectionTitle">{collection.name}</h1>
            <p className="sectionLead">{collection.description}</p>
            <div className="productGrid">
              {products.map((product) => <ProductCard product={product} key={product.slug} />)}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
