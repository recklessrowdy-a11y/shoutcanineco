import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { getProduct, products } from "@/lib/products";
import styles from "./page.module.css";

export function generateStaticParams() {
  return products.map((product) => ({ product: product.slug }));
}

export default async function ProductPage({ params }: { params: Promise<{ product: string }> }) {
  const { product: slug } = await params;
  const product = getProduct(slug);
  if (!product) notFound();

  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className={`container ${styles.layout}`}>
            <div className={styles.art}>
              <span>{product.category}</span>
              <strong>{product.name}</strong>
            </div>
            <div className={styles.copy}>
              <p className="eyebrow">{product.collection}</p>
              <h1>{product.name}</h1>
              <p className={styles.price}>${product.price.toFixed(2)}</p>
              <p>{product.description}</p>
              <div className={styles.notice}>
                <strong>Commerce adapter ready</strong>
                <p>
                  This catalog currently uses local seed data. Replace the repository adapter with
                  Shopify Storefront API data to enable live variants, inventory, checkout, and merchandising.
                </p>
              </div>
              <button className="button" type="button" disabled>Live checkout connects here</button>

              <div className={styles.links}>
                {product.breedSlug && <Link href={`/breeds/${product.breedSlug}`}>Learn about {product.breed} →</Link>}
                {product.tags.includes("body language") && <Link href="/learn/body-language">Explore body language →</Link>}
                {product.tags.includes("enrichment") && <Link href="/learn/enrichment">Explore enrichment →</Link>}
                {product.tags.includes("professional") && <Link href="/professional">Professional resources →</Link>}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
