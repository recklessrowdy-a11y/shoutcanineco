import Link from "next/link";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { ProductCard } from "@/components/commerce/ProductCard";
import { collections, products } from "@/lib/products";
import styles from "./page.module.css";

export const metadata = {
  title: "Shop",
  description: "Browse breed-inspired, educational, and professional Shout Canine Co product concepts."
};

export default function ShopPage() {
  return (
    <>
      <Header />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">Shop</p>
            <h1>Dog culture with something to say.</h1>
            <p>
              Browse the commerce architecture connecting breed identity, canine education,
              and professional resources.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.collections}>
              {collections.map((collection) => (
                <Link href={`/shop/collections/${collection.slug}`} key={collection.slug}>
                  <span>COLLECTION</span>
                  <h2>{collection.name}</h2>
                  <p>{collection.description}</p>
                  <b>Explore →</b>
                </Link>
              ))}
            </div>

            <div className={styles.heading}>
              <div>
                <p className="eyebrow">Catalog foundation</p>
                <h2 className="sectionTitle">Featured concepts</h2>
              </div>
            </div>

            <div className={styles.products}>
              {products.map((product) => <ProductCard product={product} key={product.slug} />)}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
