import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import { PlayOrProblem } from "@/components/interactive/PlayOrProblem";

export const metadata = {
  title: "Play or Problem?",
  description:
    "Practice noticing reciprocity, pauses, role reversal, disengagement, pressure, and escape opportunities in dog-dog interactions."
};

export default function PlayOrProblemPage() {
  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className="container">
            <p className="eyebrow">Interactive dog-play education</p>
            <h1 className="sectionTitle">Play or Problem?</h1>
            <p className="sectionLead">
              Practice noticing the interaction instead of relying on labels. Look for
              looseness, reciprocity, pauses, choice, disengagement, and persistent pressure.
            </p>
            <div style={{ marginTop: 40 }}>
              <PlayOrProblem />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
