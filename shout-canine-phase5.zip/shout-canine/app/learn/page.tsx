import Link from "next/link";
import { educationCategories } from "@/lib/education";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";
import styles from "./page.module.css";

export const metadata = {
  title: "Understand Dogs Better",
  description:
    "Practical canine education on body language, behavior, enrichment, play, learning, health, puppies, seniors, and professional dog care."
};

export default function LearnPage() {
  return (
    <>
      <Header />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <p className="eyebrow">Learn</p>
            <h1>Understand Dogs Better</h1>
            <p>
              Dogs communicate constantly through posture, movement, facial tension,
              distance, vocalization, environment, and behavior. The goal here is to make
              those signals easier to notice and interpret in context.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.grid}>
              {educationCategories.map((category) => (
                <Link href={`/learn/${category.slug}`} className={styles.card} key={category.slug}>
                  <span>{category.title}</span>
                  <p>{category.description}</p>
                  <b>Explore →</b>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container split">
            <div>
              <p className="eyebrow">Signature tool</p>
              <h2 className="sectionTitle">Learn to read the entire dog.</h2>
              <p className="sectionLead">
                Click body areas, compare signals, and build the habit of reading posture,
                movement, facial tension, and context together.
              </p>
              <div className="buttonRow">
                <Link className="button" href="/learn/body-language/explorer">Open Body Language Explorer</Link>
                <Link className="buttonGhost" href="/learn/enrichment/generator">Build an Enrichment Plan</Link>
              </div>
            </div>
            <div className="artPanel">
              <div className="artLabel">
                <span>INTERACTIVE EDUCATION</span>
                <strong>Body Language Explorer</strong>
                <span>Eyes · ears · mouth · tail · posture · movement</span>
              </div>
            </div>
          </div>
        
        <section className="section">
          <div className="container">
            <p className="eyebrow">Interactive learning</p>
            <h2 className="sectionTitle">Practice what you notice.</h2>
            <div className="buttonRow">
              <Link className="button" href="/learn/dog-play/play-or-problem">Play or Problem?</Link>
              <Link className="buttonGhost" href="/learn/quizzes">Test Your Dog Knowledge</Link>
              <Link className="buttonGhost" href="/tools/dog-profile">Build a Dog Profile</Link>
            </div>
          </div>
        </section>
</section>
      </main>
      <Footer />
    </>
  );
}
