import { notFound } from "next/navigation";
import { quizzes, getQuiz } from "@/lib/quizzes";
import { QuizEngine } from "@/components/interactive/QuizEngine";
import { Header } from "@/components/navigation/Header";
import { Footer } from "@/components/navigation/Footer";

export function generateStaticParams() {
  return quizzes.map((quiz) => ({ quiz: quiz.slug }));
}

export default async function QuizPage({ params }: { params: Promise<{ quiz: string }> }) {
  const { quiz: slug } = await params;
  const quiz = getQuiz(slug);
  if (!quiz) notFound();

  return (
    <>
      <Header />
      <main>
        <section className="section">
          <div className="container">
            <p className="eyebrow">Test Your Dog Knowledge</p>
            <h1 className="sectionTitle">{quiz.title}</h1>
            <p className="sectionLead">{quiz.description}</p>
            <div style={{ marginTop: 36 }}>
              <QuizEngine quiz={quiz} />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
