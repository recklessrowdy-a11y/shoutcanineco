import Link from "next/link";

export function EducationFeature() {
  return (
    <section id="learn" className="section">
      <div className="container split">
        <div>
          <p className="eyebrow">Canine education</p>
          <h2 className="sectionTitle">Learn to read the entire dog.</h2>
          <p className="sectionLead">
            Dogs communicate constantly through posture, movement, facial tension,
            distance, vocalization, environment, and behavior. One signal rarely tells the whole story.
          </p>
          <div className="buttonRow">
            <Link href="#" className="button">Open Body Language Center</Link>
            <Link href="#" className="buttonGhost">Explore Behavior Guides</Link>
          </div>
        </div>
        <div className="artPanel">
          <div className="artLabel">
            <span>INTERACTIVE EXPERIENCE</span>
            <strong>Body Language Explorer</strong>
            <span>Eyes · ears · mouth · tail · posture · movement</span>
          </div>
        </div>
      </div>
    </section>
  );
}
